import React, { useState } from 'react';
import { BookingProvider, useBooking } from './context/BookingContext';
import { Preloader } from './components/Preloader';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { CompareModal } from './components/CompareModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';


import { HomePage } from './pages/Home';
import { StaysPage } from './pages/Stays';
import { StayDetailPage } from './pages/StayDetail';
import { CheckoutPage } from './pages/Checkout';
import { ConfirmationPage } from './pages/Confirmation';
import { ExperiencesPage } from './pages/Experiences';
import { CorporatePage } from './pages/Corporate';
import { ListPropertyPage } from './pages/ListProperty';
import { AboutPage } from './pages/About';
import { CareersPage } from './pages/Careers';
import { ContactPage } from './pages/Contact';
import { PoliciesPage } from './pages/Policies';
import { NotFoundPage } from './pages/NotFound';

const AppContent: React.FC = () => {
  const { currentRoute } = useBooking();
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);

  // Router Dispatch
  const renderRoute = () => {
    // Normalise route string
    const cleanRoute = currentRoute.split('?')[0];

    if (cleanRoute === '' || cleanRoute === '/') {
      return <HomePage />;
    }
    if (cleanRoute === '/stays') {
      return <StaysPage />;
    }
    if (cleanRoute.startsWith('/stay/')) {
      return <StayDetailPage />;
    }
    if (cleanRoute === '/checkout') {
      return <CheckoutPage />;
    }
    if (cleanRoute === '/confirmed') {
      return <ConfirmationPage />;
    }
    if (cleanRoute === '/experiences') {
      return <ExperiencesPage />;
    }
    if (cleanRoute === '/corporate') {
      return <CorporatePage />;
    }
    if (cleanRoute === '/list') {
      return <ListPropertyPage />;
    }
    if (cleanRoute === '/about') {
      return <AboutPage />;
    }
    if (cleanRoute === '/careers') {
      return <CareersPage />;
    }
    if (cleanRoute === '/contact') {
      return <ContactPage />;
    }
    if (cleanRoute === '/policies') {
      return <PoliciesPage />;
    }

    return <NotFoundPage />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF6F0] selection:bg-[#F8E1E8] selection:text-[#D93A6B]">
      {/* Session Preloader (1.6s max) */}
      <Preloader />

      {/* Top Navigation */}
      <Header
        onOpenWishlist={() => setWishlistOpen(true)}
        onOpenCompare={() => setCompareOpen(true)}
      />

      {/* Active Page View */}
      <main className="flex-1">
        {renderRoute()}
      </main>

      {/* Global Modals & Overlays */}
      <WishlistDrawer
        isOpen={wishlistOpen}
        onClose={() => setWishlistOpen(false)}
      />

      <CompareModal
        isOpen={compareOpen}
        onClose={() => setCompareOpen(false)}
      />

      <FloatingWhatsApp />
      

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <BookingProvider>
      <AppContent />
    </BookingProvider>
  );
}
