export interface Review {
  id: string;
  guestName: string;
  location: string;
  stayDate: string;
  tripType: 'Solo Leisure' | 'Creative Residency' | 'Couple Getaway' | 'Executive Long Stay' | 'Family Holiday';
  rating: number; // out of 5
  comment: string;
  propertyStayed: string;
  isVerified: boolean;
}

export const REVIEWS_DATA: Review[] = [
  {
    id: 'rev-1',
    guestName: 'Devika Singhania [EDIT]',
    location: 'London, UK',
    stayDate: 'October 2026',
    tripType: 'Couple Getaway',
    rating: 5,
    comment:
      'Finding Connekt Homes in Pali Hill was such a relief after sterile 5-star hotels. The high arched windows, warm linen bedding, and the quiet cup of morning coffee on the terrace made Mumbai feel intimate and restorative.',
    propertyStayed: 'The Arched Haven at Pali Hill',
    isVerified: true,
  },
  {
    id: 'rev-2',
    guestName: 'Marc van der Meer [EDIT]',
    location: 'Amsterdam, Netherlands',
    stayDate: 'September 2026',
    tripType: 'Executive Long Stay',
    rating: 5,
    comment:
      'Stayed for 3 weeks while consulting for a fintech in BKC. The high-speed fiber internet never dropped, the workspace was truly ergonomic, and having daily unobtrusive housekeeping made it effortless.',
    propertyStayed: 'The Curator’s Flat at Pali Village',
    isVerified: true,
  },
  {
    id: 'rev-3',
    guestName: 'Ananya Roy [EDIT]',
    location: 'Bengaluru, India',
    stayDate: 'September 2026',
    tripType: 'Creative Residency',
    rating: 5,
    comment:
      'The attention to detail in Ranwar Village is unmatched. Self check-in was seamless, the aesthetic is genuinely editorial, and being a 2-minute stroll from Veronica’s deli made every morning special.',
    propertyStayed: 'Ranwar Village Atelier Suite',
    isVerified: true,
  },
  {
    id: 'rev-4',
    guestName: 'Karan & Sarah Mehta [EDIT]',
    location: 'San Francisco, USA',
    stayDate: 'August 2026',
    tripType: 'Family Holiday',
    rating: 5,
    comment:
      'The Carter Road penthouse exceeded our expectations. The sea views, the spacious open kitchen, and the warm concierge who helped coordinate our airport transfers with two young kids made our visit stress-free.',
    propertyStayed: 'The Coastal Penthouse at Carter Road',
    isVerified: true,
  },
  {
    id: 'rev-5',
    guestName: 'Tanya Fernandez [EDIT]',
    location: 'Dubai, UAE',
    stayDate: 'July 2026',
    tripType: 'Solo Leisure',
    rating: 5,
    comment:
      'Truly homes with a soul. No gimmicks, just calm colors, impeccable hygiene, and total privacy in the heart of Bandra West. I will never book another hotel in Mumbai.',
    propertyStayed: 'The Sunlit Nook on Perry Cross',
    isVerified: true,
  },
];
