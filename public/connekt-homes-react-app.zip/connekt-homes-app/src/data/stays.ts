export interface Stay {
  id: string;
  name: string;
  tagline: string;
  area: string;
  neighborhood: string;
  city: string;
  type: 'Studio' | '1 BHK' | '2 BHK' | '3 BHK Penthouse';
  guests: number;
  bedrooms: number;
  beds: number;
  bathrooms: number;
  sizeSqM: number;
  sizeSqFt: number;
  pricePerNight: number;
  originalPrice?: number;
  cleaningFee: number;
  rating: number;
  reviewCount: number;
  isSuperhost?: boolean;
  featured?: boolean;
  images: string[];
  description: string;
  conciergeNote: string;
  highlights: string[];
  amenities: {
    wifi: boolean;
    kitchen: boolean;
    ac: boolean;
    workspace: boolean;
    washer: boolean;
    smartTv: boolean;
    housekeeping: boolean;
    elevator: boolean;
    selfCheckIn: boolean;
    petsAllowed: boolean;
    parking: boolean;
    balcony: boolean;
  };
  sleepingArrangements: {
    room: string;
    bedType: string;
    details: string;
  }[];
  houseRules: string[];
  cancellationPolicy: string;
  coordinates: {
    lat: number;
    lng: number;
    xPercent: number; // for stylised interactive map
    yPercent: number;
  };
  nearbyPlaces: {
    name: string;
    distance: string;
    type: string;
  }[];
}

// Local image references from generated assets
import heroLiving from '../assets/images/hero_apartment_mumbai_1791985649199.jpg';
import salonLiving from '../assets/images/apartment_living_room_1791985649983.jpg';
import bedroomSuite from '../assets/images/apartment_bedroom_suite_1791985650346.jpg';
import kitchenDining from '../assets/images/apartment_kitchen_dining_1791985650416.jpg';
import paliStreet from '../assets/images/bandra_pali_hill_street_1791985650598.jpg';

export const STAYS_DATA: Stay[] = [
  {
    id: 'pali-haven-residence',
    name: 'The Arched Haven at Pali Hill',
    tagline: 'Sunlit living room framed by arched palms and curated ceramics',
    area: 'Pali Hill',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: '2 BHK',
    guests: 4,
    bedrooms: 2,
    beds: 2,
    bathrooms: 2,
    sizeSqM: 105,
    sizeSqFt: 1130,
    pricePerNight: 9800, // [EDIT: Sample rate in INR]
    originalPrice: 11500,
    cleaningFee: 1500,
    rating: 4.97,
    reviewCount: 48,
    isSuperhost: true,
    featured: true,
    images: [
      heroLiving,
      bedroomSuite,
      kitchenDining,
      salonLiving,
      paliStreet,
    ],
    description:
      'Tucked away along the serene bougainvillea-framed streets of Pali Hill, this expansive two-bedroom apartment offers a sanctuary of calm amidst Mumbai\'s creative pulse. Featuring tall arched floor-to-ceiling glass doors, natural travertine accents, custom fluted oak cabinetry, and an open layout bathed in gentle morning light.',
    conciergeNote:
      'Our on-ground Pali Hill host is available 8 AM to 10 PM. Fresh local sourdough and pour-over coffee beans await in the pantry on arrival.',
    highlights: [
      'Iconic arched panoramic window overlooking heritage tree canopies',
      'Dedicated walnut workstation with 300 Mbps fiber WiFi',
      'Daily quiet housekeeping with natural botanical linens',
      'Keyless digital keypad entry for effortless anytime arrivals',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: true,
      selfCheckIn: true,
      petsAllowed: false,
      parking: true,
      balcony: true,
    },
    sleepingArrangements: [
      {
        room: 'Primary Suite',
        bedType: 'King bed',
        details: '100% Belgian flax linen, ergonomic mattress, ensuite walk-in rain shower',
      },
      {
        room: 'Guest Suite',
        bedType: 'Queen bed',
        details: 'Custom oak frame, blackout drapes, quiet courtyard garden views',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM onwards / Check-out: 11:00 AM',
      'Strictly non-smoking interior (designated balcony zone available)',
      'Government ID required for all guests prior to keycode dispatch [EDIT]',
      'Quiet residential hours from 10:30 PM to 7:00 AM',
    ],
    cancellationPolicy:
      'Flexible cancellation: Full refund up to 48 hours prior to check-in. 50% refund thereafter minus service fees.',
    coordinates: {
      lat: 19.0638,
      lng: 72.8285,
      xPercent: 42,
      yPercent: 46,
    },
    nearbyPlaces: [
      { name: 'Subko Coffee Roasters', distance: '4 min walk', type: 'Specialty Cafe' },
      { name: 'Pali Village Market', distance: '6 min walk', type: 'Organic Market' },
      { name: 'Carter Road Promenade', distance: '12 min walk', type: 'Seaside Promenade' },
      { name: 'Bandra Railway Station', distance: '8 min drive', type: 'Transit' },
    ],
  },
  {
    id: 'pali-village-curators-flat',
    name: "The Curator's Flat at Pali Village",
    tagline: 'Warm oak library shelves, bougainvillea terrace, and artisanal charm',
    area: 'Pali Village',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: '1 BHK',
    guests: 2,
    bedrooms: 1,
    beds: 1,
    bathrooms: 1,
    sizeSqM: 68,
    sizeSqFt: 730,
    pricePerNight: 7200, // [EDIT]
    cleaningFee: 1200,
    rating: 4.95,
    reviewCount: 62,
    isSuperhost: true,
    featured: true,
    images: [
      salonLiving,
      bedroomSuite,
      kitchenDining,
      paliStreet,
      heroLiving,
    ],
    description:
      'Immerse yourself in the village charm of Old Pali. Designed for writers, solo executives, and couples who appreciate mid-century silhouettes and floor-to-ceiling bookshelves. Step directly out onto a sunlit balcony with terracotta planters.',
    conciergeNote:
      'Self check-in with our smart touch lock. We can stock the wine cooler and arrange laundry pressed upon request.',
    highlights: [
      'Handcrafted floor-to-ceiling library with Indian art monographs',
      'Cozy sunlit terrace overlooking heritage cottage roofs',
      'Induction cooktop, pour-over station, and curated spice rack',
      'Ergonomic boucle reading chairs with directional brass lighting',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: true,
      selfCheckIn: true,
      petsAllowed: true,
      parking: false,
      balcony: true,
    },
    sleepingArrangements: [
      {
        room: 'Master Bedroom',
        bedType: 'Queen bed',
        details: 'Handwoven cotton duvet, warm dimmable bedside lamps, noise-buffered glazing',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM onwards / Check-out: 11:00 AM',
      'Small, well-mannered pets welcome with advance notice',
      'Digital verification required 24h prior to arrival [EDIT]',
      'No parties or commercial video shoots without written permission',
    ],
    cancellationPolicy:
      'Moderate: Full refund if cancelled 5 days before arrival date.',
    coordinates: {
      lat: 19.0605,
      lng: 72.8312,
      xPercent: 52,
      yPercent: 58,
    },
    nearbyPlaces: [
      { name: 'Candies at Mac Ronells', distance: '3 min walk', type: 'Iconic Bakery & Cafe' },
      { name: 'Yauatcha / Smoke House Deli', distance: '10 min walk', type: 'Dining' },
      { name: 'Joggers Park', distance: '15 min walk', type: 'Park & Running Track' },
    ],
  },
  {
    id: 'ranwar-heritage-atelier',
    name: 'Ranwar Village Atelier Suite',
    tagline: 'Quiet Portuguese heritage quarter, sun-bleached walls and modern calm',
    area: 'Ranwar Village',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: 'Studio',
    guests: 2,
    bedrooms: 1,
    beds: 1,
    bathrooms: 1,
    sizeSqM: 48,
    sizeSqFt: 515,
    pricePerNight: 5500, // [EDIT]
    cleaningFee: 950,
    rating: 4.92,
    reviewCount: 39,
    isSuperhost: false,
    featured: true,
    images: [
      bedroomSuite,
      heroLiving,
      kitchenDining,
      paliStreet,
    ],
    description:
      'Hidden in the winding lanes of historic Ranwar Village, this minimalist designer studio is an acoustic sanctuary. High ceilings, exposed timber rafters, warm micro-cement surfaces, and a tucked-away breakfast bar.',
    conciergeNote:
      'Walking tours of Ranwar street art and Portuguese heritage villas can be booked through our neighborhood concierge.',
    highlights: [
      'Charming village square location away from arterial road traffic',
      'High-speed 250 Mbps mesh network ideal for remote deep work',
      'Nespresso machine, dual hob stove, and compact refrigerator',
      'Walkable to Bandra’s finest independent cafes and boutique bakeries',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: false,
      smartTv: true,
      housekeeping: true,
      elevator: false,
      selfCheckIn: true,
      petsAllowed: false,
      parking: false,
      balcony: false,
    },
    sleepingArrangements: [
      {
        room: 'Studio Living Suite',
        bedType: 'Queen bed',
        details: 'Low-profile solid teak platform bed with luxury cotton linens',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM / Check-out: 11:00 AM',
      'No street shoe policy inside the residence (indoor slippers provided)',
      'Government ID submission mandatory prior to check-in [EDIT]',
    ],
    cancellationPolicy:
      'Flexible: Full refund up to 48 hours prior to arrival.',
    coordinates: {
      lat: 19.0562,
      lng: 72.8335,
      xPercent: 60,
      yPercent: 72,
    },
    nearbyPlaces: [
      { name: 'Veronica’s Deli', distance: '2 min walk', type: 'Sandwiches & Coffee' },
      { name: 'Birdsong Organic Cafe', distance: '4 min walk', type: 'Organic Dining' },
      { name: 'Hill Road Shopping', distance: '5 min walk', type: 'High Street' },
    ],
  },
  {
    id: 'carter-road-coastal-penthouse',
    name: 'The Coastal Penthouse at Carter Road',
    tagline: 'Sweeping Arabian Sea horizon, wrap-around deck, and private chef setup',
    area: 'Carter Road',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: '3 BHK Penthouse',
    guests: 6,
    bedrooms: 3,
    beds: 3,
    bathrooms: 3,
    sizeSqM: 185,
    sizeSqFt: 1990,
    pricePerNight: 16800, // [EDIT]
    originalPrice: 19500,
    cleaningFee: 2500,
    rating: 4.99,
    reviewCount: 34,
    isSuperhost: true,
    featured: true,
    images: [
      kitchenDining,
      heroLiving,
      bedroomSuite,
      salonLiving,
      paliStreet,
    ],
    description:
      'Perched high above Carter Road with unobstructed panoramic vistas of the Arabian Sea and Mumbai sunsets. A premier three-bedroom serviced penthouse designed for discerning families, visiting executives, and creators.',
    conciergeNote:
      'Dedicated private butler on request. Airport transfer in a luxury vehicle can be scheduled smoothly.',
    highlights: [
      'Uninterrupted Arabian Sea panoramic views with coastal breeze',
      'Chef-grade open marble island with built-in Bosch appliances',
      'Wrap-around teak sunset terrace with outdoor dining for 8',
      '2 private covered basement parking spaces with EV charging',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: true,
      selfCheckIn: true,
      petsAllowed: true,
      parking: true,
      balcony: true,
    },
    sleepingArrangements: [
      {
        room: 'Master Sea Suite',
        bedType: 'Super King bed',
        details: 'Direct terrace access, automated blackout blinds, soaking tub',
      },
      {
        room: 'Garden Wing Suite',
        bedType: 'King bed',
        details: 'Ensuite bath, bespoke wardrobe, acoustic double-pane glass',
      },
      {
        room: 'Corner Studio Room',
        bedType: 'Queen bed',
        details: 'Dedicated ergonomic work desk, private bathroom',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM / Check-out: 11:00 AM',
      'No commercial events or loud music past 10:30 PM',
      'Verified government photo ID required [EDIT]',
    ],
    cancellationPolicy:
      'Strict: Full refund if cancelled within 48h of booking (if check-in is at least 14 days away).',
    coordinates: {
      lat: 19.0682,
      lng: 72.8228,
      xPercent: 28,
      yPercent: 32,
    },
    nearbyPlaces: [
      { name: 'Carter Road Promenade', distance: '1 min walk', type: 'Seafront' },
      { name: 'Bastian Bandra', distance: '5 min drive', type: 'Fine Dining' },
      { name: 'Bandra Bandstand', distance: '8 min drive', type: 'Scenic Coastal Point' },
    ],
  },
  {
    id: 'union-park-garden-residence',
    name: 'The Garden Residence at Union Park',
    tagline: 'Quiet leafy enclave, private courtyard patio and fluted oak interiors',
    area: 'Union Park',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: '2 BHK',
    guests: 4,
    bedrooms: 2,
    beds: 2,
    bathrooms: 2,
    sizeSqM: 110,
    sizeSqFt: 1180,
    pricePerNight: 10500, // [EDIT]
    cleaningFee: 1600,
    rating: 4.96,
    reviewCount: 51,
    isSuperhost: true,
    featured: false,
    images: [
      heroLiving,
      kitchenDining,
      bedroomSuite,
      salonLiving,
    ],
    description:
      'Union Park is known among locals as the quietest residential pocket in Bandra. This ground-level garden flat opens directly into a private landscaped patio bordered by frangipani and tropical ferns. Warm micro-cement flooring and organic textured upholstery create an earthy, restful atmosphere.',
    conciergeNote:
      'A curated welcome hamper with fresh artisanal bread, local preserves, and cold-pressed juices is provided.',
    highlights: [
      'Private 280 sq ft landscaped garden courtyard',
      'Sonos sound system and smart ambient mood lighting',
      'Filtered drinking water system and fully equipped kitchen',
      'Quiet, high-security gated residential community',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: true,
      selfCheckIn: true,
      petsAllowed: true,
      parking: true,
      balcony: true,
    },
    sleepingArrangements: [
      {
        room: 'Master Bedroom',
        bedType: 'King bed',
        details: 'Patio views, organic cotton sheets, rainfall shower',
      },
      {
        room: 'Second Bedroom',
        bedType: 'Queen bed',
        details: 'Oak wardrobe, reading chair, workstation',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM / Check-out: 11:00 AM',
      'Pets welcome in garden areas',
      'Valid identity verification required [EDIT]',
    ],
    cancellationPolicy:
      'Flexible: Cancel up to 48 hours before check-in for a full refund.',
    coordinates: {
      lat: 19.0695,
      lng: 72.8315,
      xPercent: 48,
      yPercent: 24,
    },
    nearbyPlaces: [
      { name: 'Olive Bar & Kitchen', distance: '5 min walk', type: 'Mediterranean Dining' },
      { name: 'Khar Social & Hub', distance: '7 min walk', type: 'Social & Co-working' },
      { name: 'Carter Road Joggers Park', distance: '8 min walk', type: 'Recreation' },
    ],
  },
  {
    id: 'perry-cross-light-studio',
    name: 'The Sunlit Nook on Perry Cross',
    tagline: 'Airy corner studio with wrap-around casement windows and bespoke bar',
    area: 'Perry Cross Road',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: 'Studio',
    guests: 2,
    bedrooms: 1,
    beds: 1,
    bathrooms: 1,
    sizeSqM: 52,
    sizeSqFt: 560,
    pricePerNight: 5900, // [EDIT]
    cleaningFee: 1000,
    rating: 4.93,
    reviewCount: 42,
    isSuperhost: false,
    featured: false,
    images: [
      salonLiving,
      bedroomSuite,
      heroLiving,
      kitchenDining,
    ],
    description:
      'Corner studio situated on tree-dappled Perry Cross Road. Designed for discerning solo travellers and working couples, featuring Scandinavian joinery, warm brass details, and soft linen sheer curtains that catch the afternoon sea breeze.',
    conciergeNote:
      'Self check-in anytime via digital code sent directly to your WhatsApp before arrival.',
    highlights: [
      'Bespoke oak foldaway desk with ergonomic Hay chair',
      'Nespresso machine, induction cooker, and Smeg toaster',
      'Walkable distance to Bandra’s premier yoga and pilates studios',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: true,
      selfCheckIn: true,
      petsAllowed: false,
      parking: false,
      balcony: false,
    },
    sleepingArrangements: [
      {
        room: 'Studio Suite',
        bedType: 'Queen bed',
        details: 'Pocket-spring mattress, hypo-allergenic pillows, bedside USB-C charging',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM / Check-out: 11:00 AM',
      'Strictly non-smoking unit',
      'Government ID mandatory [EDIT]',
    ],
    cancellationPolicy:
      'Flexible: Full refund up to 48 hours prior to arrival.',
    coordinates: {
      lat: 19.0621,
      lng: 72.8298,
      xPercent: 44,
      yPercent: 50,
    },
    nearbyPlaces: [
      { name: 'The Daily All Day', distance: '3 min walk', type: 'Brunch & Cocktails' },
      { name: 'Yoga 101 Bandra', distance: '5 min walk', type: 'Wellness' },
      { name: 'Pali Market', distance: '5 min walk', type: 'Artisan Grocers' },
    ],
  },
  {
    id: 'chimbai-seaside-retreat',
    name: 'Chimbai Coastal Retreat',
    tagline: 'Quiet seaside alleyways, high ceilings, and ocean-facing reading alcove',
    area: 'Chimbai Village',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: '1 BHK',
    guests: 3,
    bedrooms: 1,
    beds: 2,
    bathrooms: 1,
    sizeSqM: 74,
    sizeSqFt: 795,
    pricePerNight: 7800, // [EDIT]
    cleaningFee: 1300,
    rating: 4.94,
    reviewCount: 57,
    isSuperhost: true,
    featured: false,
    images: [
      heroLiving,
      bedroomSuite,
      kitchenDining,
      paliStreet,
    ],
    description:
      'Experience the authentic fishing village charm of Bandra West with modern boutique luxury. Quiet and hidden, with floor-to-ceiling windows, soothing neutral textiles, and a reading daybed overlooking the coastal horizon.',
    conciergeNote:
      'Our team is happy to recommend hidden Bandra breakfast stalls and sunset vantage points.',
    highlights: [
      'Built-in daybed alcove perfect for afternoon reading or an extra guest',
      'Washer-dryer in unit and fully fitted kitchen',
      '5 minutes stroll to Carter Road waterfront',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: false,
      selfCheckIn: true,
      petsAllowed: true,
      parking: false,
      balcony: true,
    },
    sleepingArrangements: [
      {
        room: 'Bedroom',
        bedType: 'King bed',
        details: 'Calm tones, natural linen blinds, reading sconces',
      },
      {
        room: 'Living Alcove',
        bedType: 'Single Daybed',
        details: 'Cushioned window alcove with linen pillows',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM / Check-out: 11:00 AM',
      'Quiet hours after 10:30 PM',
      'Valid photo ID required [EDIT]',
    ],
    cancellationPolicy:
      'Flexible: Full refund up to 48 hours prior to check-in.',
    coordinates: {
      lat: 19.0545,
      lng: 72.8260,
      xPercent: 36,
      yPercent: 78,
    },
    nearbyPlaces: [
      { name: 'Bombay Salad Co.', distance: '7 min walk', type: 'Healthy Dining' },
      { name: 'Carter Road Promontory', distance: '4 min walk', type: 'Waterfront' },
    ],
  },
  {
    id: 'mount-mary-sanctuary',
    name: 'Mount Mary Heritage Sanctuary',
    tagline: 'Perched near the historic basilica, serene breezes and terracotta vistas',
    area: 'Mount Mary',
    neighborhood: 'Bandra West',
    city: 'Mumbai',
    type: '2 BHK',
    guests: 4,
    bedrooms: 2,
    beds: 2,
    bathrooms: 2,
    sizeSqM: 115,
    sizeSqFt: 1240,
    pricePerNight: 11200, // [EDIT]
    cleaningFee: 1700,
    rating: 4.98,
    reviewCount: 46,
    isSuperhost: true,
    featured: true,
    images: [
      salonLiving,
      heroLiving,
      bedroomSuite,
      kitchenDining,
      paliStreet,
    ],
    description:
      'Nestled near Mount Mary Basilica on a peaceful hillside ridge. This elevated apartment enjoys cool cross-breezes and views over heritage terracotta roofs. Completed with custom fluted timber partitions, a state-of-the-art kitchen, and expansive master suite.',
    conciergeNote:
      'Personal grocery delivery and morning yoga instructor on the terrace can be arranged.',
    highlights: [
      'Elevated hill view with ocean breezes and heritage church bells',
      'Dual ensuite bedrooms each with dedicated private balconies',
      'High-speed WiFi mesh with uninterrupted backup power supply',
    ],
    amenities: {
      wifi: true,
      kitchen: true,
      ac: true,
      workspace: true,
      washer: true,
      smartTv: true,
      housekeeping: true,
      elevator: true,
      selfCheckIn: true,
      petsAllowed: false,
      parking: true,
      balcony: true,
    },
    sleepingArrangements: [
      {
        room: 'Master Sanctuary',
        bedType: 'King bed',
        details: 'Private balcony, walk-in closet, rain shower with city glimpses',
      },
      {
        room: 'Guest Sanctuary',
        bedType: 'Queen bed',
        details: 'Oak desk, curated ceramics, blackout blinds',
      },
    ],
    houseRules: [
      'Check-in: 3:00 PM / Check-out: 11:00 AM',
      'No loud music past 10:00 PM',
      'Verification with passport or Aadhaar mandatory [EDIT]',
    ],
    cancellationPolicy:
      'Flexible: Full refund up to 48 hours prior to check-in.',
    coordinates: {
      lat: 19.0475,
      lng: 72.8222,
      xPercent: 30,
      yPercent: 86,
    },
    nearbyPlaces: [
      { name: 'Mount Mary Basilica', distance: '3 min walk', type: 'Historic Landmark' },
      { name: 'Bandstand Promenade', distance: '6 min walk', type: 'Coastal Walk' },
      { name: 'Taj Lands End', distance: '8 min walk', type: 'Luxury Hotel & Spa' },
    ],
  },
];
