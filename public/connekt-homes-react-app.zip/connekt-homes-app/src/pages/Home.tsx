import React, { useState } from 'react';
import { useBooking, formatINR } from '../context/BookingContext';
import { REVIEWS_DATA } from '../data/reviews';
import { SearchCard } from '../components/SearchCard';
import { StayCard } from '../components/StayCard';
import { DayAtConnekt } from '../sections/DayAtConnekt';
import { AmenitiesGrid } from '../sections/AmenitiesGrid';
import { NeighbourhoodMap } from '../sections/NeighbourhoodMap';
import { GuestStories } from '../sections/GuestStories';
import { OfferBanner } from '../sections/OfferBanner';
import { CorporateOwnerCards } from '../sections/CorporateOwnerCards';
import { InstagramGrid } from '../sections/InstagramGrid';
import { FaqAccordion } from '../sections/FaqAccordion';

import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Star,
  Check,
  Heart,
  Home,
  Coffee,
  Clock,
  Compass,
} from 'lucide-react';

import heroLiving from '../assets/images/hero_apartment_mumbai_1791985649199.jpg';

export const HomePage: React.FC = () => {
  const { allStays, navigateTo } = useBooking();
  const [filterType, setFilterType] = useState<string>('all');

  const filteredStays =
    filterType === 'all'
      ? allStays.slice(0, 4)
      : allStays.filter((s) => s.type.toLowerCase().includes(filterType.toLowerCase())).slice(0, 4);

  return (
    <div className="space-y-0">
      {/* 1. HERO SECTION */}
      <section className="relative min-h-[85vh] lg:min-h-[90vh] flex flex-col justify-between pt-12 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden bg-[#FAF6F0]">
        {/* Soft Arched Focal Visual Backdrop Container */}
        <div className="max-w-7xl mx-auto w-full relative z-10 flex-1 flex flex-col justify-between">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-4 sm:pt-8 mb-12">
            {/* Left Headline & Pitch */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EFE6DA] text-[#14213D] text-xs font-semibold tracking-wider uppercase border border-[#14213D]/10">
                <span className="w-2 h-2 rounded-full bg-[#D93A6B]" />
                <span>Bandra West & Pali Hill · Mumbai</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-6xl lg:text-[72px] text-[#14213D] font-normal leading-[1.08] tracking-tight">
                Homes with a soul, <br className="hidden sm:inline" />
                <span className="italic">wherever you land.</span>
              </h1>

              <p className="text-base sm:text-lg text-[#2B2F3A]/80 max-w-xl font-sans leading-relaxed">
                Short-term serviced residences for the global traveller. Full kitchens, sunlit living areas, daily housekeeping, and quiet concierge support in Mumbai’s cultural heart.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => navigateTo('/stays')}
                  className="px-6 py-3.5 bg-[#D93A6B] hover:bg-[#c42f5d] text-white text-xs font-semibold uppercase tracking-wider rounded-[10px] shadow-sm transition-all flex items-center gap-2 group cursor-pointer"
                >
                  <span>Explore Stays</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
                <button
                  onClick={() => navigateTo('/experiences')}
                  className="px-6 py-3.5 bg-transparent hover:bg-[#EFE6DA] text-[#14213D] border border-[#14213D]/30 text-xs font-semibold uppercase tracking-wider rounded-[10px] transition-colors cursor-pointer"
                >
                  Neighbourhood Guide
                </button>
              </div>
            </div>

            {/* Right Focal Image with Soft Arch Top */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Decorative hairline backdrop */}
                <div className="absolute -inset-2 rounded-t-[200px] rounded-b-[16px] border border-[#B89B72]/30 pointer-events-none transform -rotate-1" />

                <div className="relative rounded-t-[190px] rounded-b-[14px] overflow-hidden aspect-[3/4] shadow-[0_25px_60px_rgba(20,33,61,0.14)] bg-[#14213D]">
                  <img
                    src={heroLiving}
                    alt="Sunlit serviced apartment living room in Bandra Mumbai"
                    className="w-full h-full object-cover transition-transform duration-1000 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#14213D]/80 via-transparent to-transparent pointer-events-none" />

                  {/* Float tag on bottom */}
                  <div className="absolute bottom-5 left-5 right-5 text-white z-10 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-[#B89B72] block">
                        Featured Residence
                      </span>
                      <span className="font-serif text-lg font-medium">The Arched Haven</span>
                    </div>
                    <span className="text-xs font-semibold bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-[6px] border border-white/20">
                      Pali Hill
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Elevated Search Card */}
          <div className="w-full pt-4">
            <SearchCard />
          </div>
        </div>
      </section>

      {/* 2. BRAND STATEMENT & EDITORIAL STATS */}
      <section className="py-20 sm:py-28 bg-[#FAF6F0] border-t border-[#14213D]/10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#B89B72]">
            The Connekt Ethos
          </div>

          <p className="font-serif text-2xl sm:text-3xl md:text-4xl text-[#14213D] leading-relaxed tracking-tight max-w-4xl mx-auto font-normal">
            “We founded Connekt Homes on a simple truth: global travellers do not want sterile hotel boxes. They crave <span className="italic">lived-in warmth</span>, authentic neighbourhood rhythms, and the unpretentious sanctuary of an actual home—delivered with flawless hospitality.”
          </p>

          <div className="text-xs uppercase tracking-[0.2em] text-[#2B2F3A]/60 pt-2 font-medium">
            Boutique Serviced Living · Curated in Mumbai
          </div>

          {/* 3 Stats [EDIT] */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-10 border-t border-[#14213D]/10 max-w-3xl mx-auto">
            <div>
              <div className="font-serif text-3xl sm:text-4xl font-semibold text-[#14213D]">
                4.96 <span className="text-sm font-sans text-[#B89B72]">★</span>
              </div>
              <div className="text-xs text-[#2B2F3A]/70 uppercase tracking-wider font-medium mt-1">
                Average Guest Rating [EDIT]
              </div>
            </div>

            <div>
              <div className="font-serif text-3xl sm:text-4xl font-semibold text-[#14213D]">
                100%
              </div>
              <div className="text-xs text-[#2B2F3A]/70 uppercase tracking-wider font-medium mt-1">
                Verified Residences [EDIT]
              </div>
            </div>

            <div>
              <div className="font-serif text-3xl sm:text-4xl font-semibold text-[#14213D]">
                24 / 7
              </div>
              <div className="text-xs text-[#2B2F3A]/70 uppercase tracking-wider font-medium mt-1">
                On-Ground Concierge Care [EDIT]
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED STAYS CAROUSEL / GRID */}
      <section className="py-20 sm:py-28 bg-[#FAF6F0] border-t border-[#14213D]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#B89B72] mb-2">
                Handpicked Collections
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#14213D] tracking-tight">
                Featured <span className="italic font-normal">residences</span>
              </h2>
            </div>

            {/* Quick Filter Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-[#EFE6DA]/60 rounded-[12px] border border-[#14213D]/10">
              {[
                { label: 'All Stays', value: 'all' },
                { label: 'Studios', value: 'studio' },
                { label: '1 BHK', value: '1 bhk' },
                { label: '2 & 3 BHK', value: 'bhk' },
              ].map((tab) => (
                <button
                  key={tab.value}
                  onClick={() => setFilterType(tab.value)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-[8px] transition-colors cursor-pointer ${
                    filterType === tab.value
                      ? 'bg-white text-[#14213D] shadow-xs font-semibold'
                      : 'text-[#2B2F3A]/70 hover:text-[#14213D]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredStays.map((stay) => (
              <StayCard key={stay.id} stay={stay} />
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => navigateTo('/stays')}
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-[10px] bg-[#14213D] hover:bg-[#D93A6B] text-white text-xs font-semibold uppercase tracking-wider transition-colors shadow-sm cursor-pointer"
            >
              <span>View All 8+ Bandra Residences</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 4. WHY CONNEKT: 4 PILLARS */}
      <section className="py-20 sm:py-28 bg-[#FAF6F0] border-t border-[#14213D]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#B89B72] mb-2">
              The Connekt Promise
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#14213D] tracking-tight">
              Why travellers choose <span className="italic font-normal">Connekt</span>
            </h2>
            <p className="text-sm sm:text-base text-[#2B2F3A]/70 mt-3 leading-relaxed">
              Every detail is calibrated to offer effortless comfort, complete privacy, and a deep sense of belonging.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-[20px] p-8 border border-[#14213D]/10 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-[12px] bg-[#F8E1E8] text-[#D93A6B] flex items-center justify-center mb-6">
                  <Home className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-[#14213D] mb-3">
                  Homes, Not Rooms
                </h3>
                <p className="text-xs sm:text-sm text-[#2B2F3A]/75 leading-relaxed font-sans">
                  Separate living rooms, dedicated dining spaces, and complete kitchens so you can cook, entertain, and spread out in comfort.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-[#14213D]/5 text-xs text-[#B89B72] font-semibold uppercase tracking-wider">
                01 · Generous Space
              </div>
            </div>

            <div className="bg-white rounded-[20px] p-8 border border-[#14213D]/10 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-[12px] bg-[#EFE6DA] text-[#14213D] flex items-center justify-center mb-6">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-[#14213D] mb-3">
                  Hotel-Grade Care
                </h3>
                <p className="text-xs sm:text-sm text-[#2B2F3A]/75 leading-relaxed font-sans">
                  Spotless daily housekeeping, natural botanical toiletries, crisp 400-thread count cotton sheets, and responsive concierge support.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-[#14213D]/5 text-xs text-[#B89B72] font-semibold uppercase tracking-wider">
                02 · Spotless Hygiene
              </div>
            </div>

            <div className="bg-white rounded-[20px] p-8 border border-[#14213D]/10 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-[12px] bg-[#EFE6DA] text-[#2A8CB5] flex items-center justify-center mb-6">
                  <Compass className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-[#14213D] mb-3">
                  Live Like a Local
                </h3>
                <p className="text-xs sm:text-sm text-[#2B2F3A]/75 leading-relaxed font-sans">
                  Immerse yourself in authentic Bandra life. Stroll down leafy lanes to morning bakeries, local fruit stalls, and seaside cafes.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-[#14213D]/5 text-xs text-[#B89B72] font-semibold uppercase tracking-wider">
                03 · Village Neighborhoods
              </div>
            </div>

            <div className="bg-white rounded-[20px] p-8 border border-[#14213D]/10 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-[12px] bg-[#F8E1E8] text-[#D93A6B] flex items-center justify-center mb-6">
                  <Clock className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-[#14213D] mb-3">
                  Stay As Long As You Like
                </h3>
                <p className="text-xs sm:text-sm text-[#2B2F3A]/75 leading-relaxed font-sans">
                  From weekend creative retreats to multi-month corporate relocations with flexible month-to-month terms and GST tax invoicing.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-[#14213D]/5 text-xs text-[#B89B72] font-semibold uppercase tracking-wider">
                04 · Flexible Durations
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. A DAY AT CONNEKT PINNED STORY */}
      <DayAtConnekt />

      {/* 6. AMENITIES GRID */}
      <AmenitiesGrid />

      {/* 7. NEIGHBOURHOOD / MAP */}
      <NeighbourhoodMap />

      {/* 8. GUEST STORIES (NAVY BAND) */}
      <GuestStories />

      {/* 9. REVIEWS SECTION */}
      <section className="py-20 sm:py-28 bg-[#FAF6F0] border-t border-[#14213D]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#B89B72] mb-2">
                Verified Guest Words
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#14213D] tracking-tight">
                Guest reflections <span className="italic font-normal">on their stay</span>
              </h2>
            </div>

            <div className="text-xs text-[#2B2F3A]/60">
              [Review names and places marked as placeholders [EDIT]]
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS_DATA.slice(0, 3).map((review) => (
              <div
                key={review.id}
                className="bg-white rounded-[20px] p-6 sm:p-8 border border-[#14213D]/10 shadow-xs flex flex-col justify-between"
              >
                <div>
                  {/* Brass Stars */}
                  <div className="flex items-center gap-1 mb-4 text-[#B89B72]">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>

                  <p className="font-serif italic text-base text-[#14213D] leading-relaxed mb-6">
                    “{review.comment}”
                  </p>
                </div>

                <div className="pt-4 border-t border-[#14213D]/10 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-[#14213D]">{review.guestName}</div>
                    <div className="text-[11px] text-[#2B2F3A]/60">
                      {review.location} · {review.tripType}
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-[#9DB5A0] bg-[#9DB5A0]/15 px-2 py-0.5 rounded">
                    Verified Stay
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. OFFER BANNER */}
      <OfferBanner />

      {/* 11. CORPORATE & OWNERS */}
      <CorporateOwnerCards />

      {/* 12. INSTAGRAM GRID */}
      <InstagramGrid />

      {/* 13. FAQ */}
      <FaqAccordion />

      {/* 14. FINAL CTA BAND */}
      <section className="py-24 bg-[#FAF6F0] border-t border-[#14213D]/10 relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 space-y-8">
          <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#B89B72]">
            Begin Your Mumbai Stay
          </div>

          <h2 className="font-serif text-3xl sm:text-5xl md:text-6xl text-[#14213D] font-medium tracking-tight">
            Your home away from home is <br />
            <span className="italic font-normal">one search away.</span>
          </h2>

          <p className="text-sm sm:text-base text-[#2B2F3A]/75 max-w-xl mx-auto font-sans leading-relaxed">
            Reserve directly for best guaranteed rates, complimentary early check-in when available, and personalized on-ground concierge support.
          </p>

          <div className="pt-4">
            <SearchCard compact={true} />
          </div>
        </div>
      </section>
    </div>
  );
};
