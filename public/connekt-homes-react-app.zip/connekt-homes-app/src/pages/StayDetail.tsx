import React, { useState, useEffect } from 'react';
import { useBooking, formatINR } from '../context/BookingContext';
import { StayCard } from '../components/StayCard';
import {
  Heart,
  Share2,
  Star,
  MapPin,
  Check,
  ShieldCheck,
  Users,
  Bed,
  Bath,
  Maximize2,
  Calendar,
  MessageCircle,
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Info,
  Clock,
  ArrowRight,
  Wifi,
  UtensilsCrossed,
  Laptop,
  Wind,
} from 'lucide-react';

export const StayDetailPage: React.FC = () => {
  const {
    routeParams,
    allStays,
    navigateTo,
    wishlist,
    toggleWishlist,
    bookingDetails,
    updateBookingDetails,
    calculatePricing,
    addRecentlyViewed,
  } = useBooking();

  const stayId = routeParams.id || allStays[0]?.id;
  const stay = allStays.find((s) => s.id === stayId) || allStays[0];

  useEffect(() => {
    if (stay) {
      addRecentlyViewed(stay.id);
      updateBookingDetails({ stayId: stay.id });
    }
  }, [stayId]);

  // Full-screen Lightbox Gallery
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);

  // Booking Card State inside Detail
  const [nights, setNights] = useState(bookingDetails.nights || 3);
  const [checkIn, setCheckIn] = useState(bookingDetails.checkInDate);
  const [checkOut, setCheckOut] = useState(bookingDetails.checkOutDate);
  const [guestsCount, setGuestsCount] = useState(Math.min(bookingDetails.guests || 2, stay.guests));

  useEffect(() => {
    updateBookingDetails({
      stayId: stay.id,
      checkInDate: checkIn,
      checkOutDate: checkOut,
      guests: guestsCount,
    });
  }, [checkIn, checkOut, guestsCount, stay.id]);

  const pricing = calculatePricing(stay, {
    ...bookingDetails,
    nights,
    guests: guestsCount,
    stayId: stay.id,
  });

  const isSaved = wishlist.includes(stay.id);

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!lightboxOpen) return;
      if (e.key === 'Escape') setLightboxOpen(false);
      if (e.key === 'ArrowRight') {
        setActivePhotoIndex((prev) => (prev + 1) % stay.images.length);
      }
      if (e.key === 'ArrowLeft') {
        setActivePhotoIndex((prev) => (prev === 0 ? stay.images.length - 1 : prev - 1));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxOpen, stay.images.length]);

  const handleDateChange = (startStr: string, endStr: string) => {
    setCheckIn(startStr);
    setCheckOut(endStr);
    const start = new Date(startStr);
    const end = new Date(endStr);
    const diffDays = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
    setNights(diffDays);
  };

  const handleReserve = () => {
    updateBookingDetails({
      stayId: stay.id,
      checkInDate: checkIn,
      checkOutDate: checkOut,
      nights,
      guests: guestsCount,
    });
    navigateTo('/checkout');
  };

  // WhatsApp Pre-filled link
  const waMsg = `Hello Connekt Concierge! I'm looking at ${stay.name} (${stay.area}) from ${checkIn} to ${checkOut} for ${guestsCount} guests. Is this available?`;
  const waUrl = `https://wa.me/919800000000?text=${encodeURIComponent(waMsg)}`;

  // Similar Stays
  const similarStays = allStays.filter((s) => s.id !== stay.id).slice(0, 3);

  return (
    <div className="bg-[#FAF6F0] min-h-screen pb-32">
      {/* Stay Top Subnav Bar */}
      <div className="border-b border-[#14213D]/10 bg-white py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-[#2B2F3A]/60">
            <button onClick={() => navigateTo('/stays')} className="hover:text-[#14213D]">
              Stays
            </button>
            <span>/</span>
            <span className="text-[#14213D] font-medium">{stay.area}</span>
            <span>/</span>
            <span className="truncate max-w-[200px] text-[#2B2F3A]/80">{stay.name}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: stay.name, url: window.location.href });
                } else {
                  navigator.clipboard.writeText(window.location.href);
                }
              }}
              className="flex items-center gap-1.5 text-[#2B2F3A] hover:text-[#D93A6B] transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Share</span>
            </button>
            <button
              onClick={() => toggleWishlist(stay.id)}
              className="flex items-center gap-1.5 text-[#2B2F3A] hover:text-[#D93A6B] transition-colors"
            >
              <Heart
                className={`w-4 h-4 ${isSaved ? 'fill-[#D93A6B] text-[#D93A6B]' : 'text-[#2B2F3A]'}`}
              />
              <span className="hidden sm:inline">{isSaved ? 'Saved' : 'Save'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Title and High-Level Details */}
        <div className="mb-6">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#B89B72] mb-1.5">
            <span>{stay.area} · {stay.neighborhood}</span>
            <span>·</span>
            <span>{stay.type}</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#14213D] tracking-tight">
            {stay.name}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-[#2B2F3A]/80 mt-2">
            <div className="flex items-center gap-1 text-[#14213D] font-semibold">
              <Star className="w-4 h-4 fill-[#B89B72] text-[#B89B72]" />
              <span>{stay.rating.toFixed(2)}</span>
              <span className="text-[#2B2F3A]/60 font-normal">({stay.reviewCount} verified reviews)</span>
            </div>
            <span>·</span>
            <span>{stay.guests} guests max</span>
            <span>·</span>
            <span>{stay.bedrooms} bedrooms</span>
            <span>·</span>
            <span>{stay.bathrooms} bathrooms</span>
            <span>·</span>
            <span>{stay.sizeSqFt} sq ft ({stay.sizeSqM} m²)</span>
          </div>
        </div>

        {/* Gallery Grid (One large + 4 thumbnails) */}
        <div className="relative rounded-[20px] overflow-hidden mb-12 shadow-sm border border-[#14213D]/10">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-2 h-[340px] sm:h-[460px] md:h-[540px]">
            {/* Primary Large Image */}
            <div
              className="md:col-span-8 relative cursor-pointer overflow-hidden group"
              onClick={() => {
                setActivePhotoIndex(0);
                setLightboxOpen(true);
              }}
            >
              <img
                src={stay.images[0]}
                alt={stay.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
            </div>

            {/* 4 Thumbnails on right */}
            <div className="hidden md:grid md:col-span-4 grid-cols-2 gap-2">
              {stay.images.slice(1, 5).map((img, idx) => (
                <div
                  key={idx}
                  className="relative cursor-pointer overflow-hidden group h-full"
                  onClick={() => {
                    setActivePhotoIndex(idx + 1);
                    setLightboxOpen(true);
                  }}
                >
                  <img
                    src={img}
                    alt={`${stay.name} gallery view ${idx + 2}`}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
                </div>
              ))}
            </div>
          </div>

          {/* View All Photos Button */}
          <button
            onClick={() => {
              setActivePhotoIndex(0);
              setLightboxOpen(true);
            }}
            className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-md hover:bg-white text-[#14213D] text-xs font-semibold px-4 py-2.5 rounded-[10px] shadow-md border border-[#14213D]/10 flex items-center gap-2 cursor-pointer transition-transform active:scale-95"
          >
            <Maximize2 className="w-3.5 h-3.5 text-[#D93A6B]" />
            <span>Show all {stay.images.length} photos</span>
          </button>
        </div>

        {/* Content Layout: Left Story + Right Sticky Booking Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Details Column */}
          <div className="lg:col-span-7 space-y-12">
            {/* Concierge Note Banner */}
            <div className="bg-[#EFE6DA]/70 rounded-[18px] p-6 border border-[#14213D]/10 flex items-start gap-4">
              <div className="w-10 h-10 rounded-[10px] bg-[#14213D] text-[#FAF6F0] flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5 text-[#B89B72]" />
              </div>
              <div className="text-xs sm:text-sm text-[#2B2F3A]/85 leading-relaxed">
                <span className="font-semibold text-[#14213D] block text-xs uppercase tracking-wider mb-1">
                  On-Ground Concierge Note
                </span>
                {stay.conciergeNote}
              </div>
            </div>

            {/* Highlights Chips */}
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#B89B72] mb-4">
                Residence Highlights
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {stay.highlights.map((highlight, idx) => (
                  <div
                    key={idx}
                    className="bg-white rounded-[12px] p-3.5 border border-[#14213D]/10 shadow-xs flex items-start gap-3"
                  >
                    <Check className="w-4 h-4 text-[#D93A6B] shrink-0 mt-0.5" />
                    <span className="text-xs font-medium text-[#14213D] leading-snug">
                      {highlight}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* About this Home */}
            <div className="pt-6 border-t border-[#14213D]/10 space-y-4">
              <h2 className="font-serif text-2xl font-medium text-[#14213D]">
                About this home
              </h2>
              <p className="text-sm sm:text-base text-[#2B2F3A]/80 font-sans leading-relaxed">
                {stay.description}
              </p>
            </div>

            {/* Where you will sleep */}
            <div className="pt-6 border-t border-[#14213D]/10 space-y-4">
              <h2 className="font-serif text-2xl font-medium text-[#14213D]">
                Where you’ll sleep
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {stay.sleepingArrangements.map((room, idx) => (
                  <div
                    key={idx}
                    className="bg-white rounded-[16px] p-5 border border-[#14213D]/10 shadow-xs"
                  >
                    <Bed className="w-5 h-5 text-[#D93A6B] mb-3" />
                    <h3 className="font-serif text-base font-semibold text-[#14213D]">
                      {room.room}
                    </h3>
                    <div className="text-xs font-bold text-[#B89B72] uppercase tracking-wider mt-0.5 mb-2">
                      {room.bedType}
                    </div>
                    <p className="text-xs text-[#2B2F3A]/70 leading-relaxed font-sans">
                      {room.details}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Full Amenities */}
            <div className="pt-6 border-t border-[#14213D]/10 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="font-serif text-2xl font-medium text-[#14213D]">
                  Amenities & Comforts
                </h2>
                <span className="text-xs text-[#2B2F3A]/60">Hotel-grade standards</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-[#14213D]">
                <div className="bg-white p-3 rounded-[10px] border border-[#14213D]/10 flex items-center gap-2">
                  <Wifi className="w-4 h-4 text-[#2A8CB5]" />
                  <span>300 Mbps Fiber WiFi</span>
                </div>
                <div className="bg-white p-3 rounded-[10px] border border-[#14213D]/10 flex items-center gap-2">
                  <UtensilsCrossed className="w-4 h-4 text-[#2A8CB5]" />
                  <span>Full Kitchen & Oven</span>
                </div>
                <div className="bg-white p-3 rounded-[10px] border border-[#14213D]/10 flex items-center gap-2">
                  <Wind className="w-4 h-4 text-[#2A8CB5]" />
                  <span>Split Inverter AC</span>
                </div>
                <div className="bg-white p-3 rounded-[10px] border border-[#14213D]/10 flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-[#2A8CB5]" />
                  <span>Dedicated Workstation</span>
                </div>
                <div className="bg-white p-3 rounded-[10px] border border-[#14213D]/10 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#2A8CB5]" />
                  <span>Daily Housekeeping</span>
                </div>
                <div className="bg-white p-3 rounded-[10px] border border-[#14213D]/10 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#2A8CB5]" />
                  <span>24/7 Gated Security</span>
                </div>
              </div>
            </div>

            {/* House Rules */}
            <div className="pt-6 border-t border-[#14213D]/10 space-y-4">
              <h2 className="font-serif text-2xl font-medium text-[#14213D]">
                House rules & Arrival
              </h2>
              <ul className="space-y-2 text-xs sm:text-sm text-[#2B2F3A]/80">
                {stay.houseRules.map((rule, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D93A6B] mt-2 shrink-0" />
                    <span>{rule}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Cancellation Policy */}
            <div className="pt-6 border-t border-[#14213D]/10 space-y-2">
              <h2 className="font-serif text-xl font-medium text-[#14213D]">
                Cancellation policy
              </h2>
              <p className="text-xs sm:text-sm text-[#2B2F3A]/80 leading-relaxed">
                {stay.cancellationPolicy}
              </p>
            </div>

            {/* Location & Mini Map */}
            <div className="pt-6 border-t border-[#14213D]/10 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-serif text-2xl font-medium text-[#14213D]">
                    Where you’ll be
                  </h2>
                  <p className="text-xs text-[#2B2F3A]/70 mt-0.5">
                    {stay.area}, {stay.neighborhood}, Mumbai
                  </p>
                </div>
                <span className="text-xs font-mono text-[#B89B72]">Bandra West</span>
              </div>

              {/* Nearby Proximity Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {stay.nearbyPlaces.map((place, idx) => (
                  <div
                    key={idx}
                    className="bg-white p-3.5 rounded-[12px] border border-[#14213D]/10 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-[#14213D]">{place.name}</div>
                      <div className="text-[11px] text-[#2B2F3A]/60">{place.type}</div>
                    </div>
                    <span className="font-mono text-[#D93A6B] font-semibold text-[11px] bg-[#F8E1E8] px-2 py-0.5 rounded">
                      {place.distance}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Sticky Booking Card (Desktop) */}
          <div className="hidden lg:block lg:col-span-5 sticky top-28">
            <div className="bg-white rounded-[24px] p-6 sm:p-8 border border-[#14213D]/12 shadow-[0_25px_60px_rgba(20,33,61,0.09)] space-y-6">
              {/* Price per night header */}
              <div className="flex items-baseline justify-between pb-4 border-b border-[#14213D]/10">
                <div>
                  <span className="text-2xl sm:text-3xl font-bold text-[#14213D] font-sans">
                    {formatINR(stay.pricePerNight)}
                  </span>
                  <span className="text-xs text-[#2B2F3A]/60 font-normal"> / night</span>
                </div>
                <div className="flex items-center gap-1 text-xs font-semibold text-[#14213D]">
                  <Star className="w-3.5 h-3.5 fill-[#B89B72] text-[#B89B72]" />
                  <span>{stay.rating.toFixed(2)}</span>
                  <span className="text-[#2B2F3A]/50">({stay.reviewCount})</span>
                </div>
              </div>

              {/* Date & Guests Selection */}
              <div className="border border-[#14213D]/15 rounded-[14px] overflow-hidden divide-y divide-[#14213D]/15">
                <div className="grid grid-cols-2 divide-x divide-[#14213D]/15">
                  <div className="p-3 bg-[#FAF6F0]/40">
                    <label className="text-[10px] font-semibold uppercase tracking-wider text-[#B89B72] block">
                      Check-in
                    </label>
                    <input
                      type="date"
                      value={checkIn}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => handleDateChange(e.target.value, checkOut)}
                      className="w-full text-xs font-semibold text-[#14213D] bg-transparent focus:outline-none mt-0.5"
                    />
                  </div>
                  <div className="p-3 bg-[#FAF6F0]/40">
                    <label className="text-[10px] font-semibold uppercase tracking-wider text-[#B89B72] block">
                      Check-out
                    </label>
                    <input
                      type="date"
                      value={checkOut}
                      min={checkIn}
                      onChange={(e) => handleDateChange(checkIn, e.target.value)}
                      className="w-full text-xs font-semibold text-[#14213D] bg-transparent focus:outline-none mt-0.5"
                    />
                  </div>
                </div>

                <div className="p-3 bg-[#FAF6F0]/40 flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-semibold uppercase tracking-wider text-[#B89B72] block">
                      Guests
                    </label>
                    <div className="text-xs font-semibold text-[#14213D]">
                      {guestsCount} {guestsCount === 1 ? 'Guest' : 'Guests'} (Max {stay.guests})
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setGuestsCount(Math.max(1, guestsCount - 1))}
                      disabled={guestsCount <= 1}
                      className="w-7 h-7 rounded-full border border-[#14213D]/20 flex items-center justify-center text-xs font-bold disabled:opacity-30"
                    >
                      -
                    </button>
                    <button
                      type="button"
                      onClick={() => setGuestsCount(Math.min(stay.guests, guestsCount + 1))}
                      disabled={guestsCount >= stay.guests}
                      className="w-7 h-7 rounded-full border border-[#14213D]/20 flex items-center justify-center text-xs font-bold disabled:opacity-30"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Live Price Breakdown */}
              <div className="space-y-2.5 text-xs text-[#2B2F3A]/80 pt-2 border-t border-[#14213D]/10">
                <div className="flex justify-between">
                  <span>
                    {formatINR(stay.pricePerNight)} × {nights} {nights === 1 ? 'night' : 'nights'}
                  </span>
                  <span className="font-semibold text-[#14213D]">
                    {formatINR(pricing.accommodationTotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Daily Housekeeping & Preparation Fee</span>
                  <span className="font-semibold text-[#14213D]">
                    {formatINR(pricing.cleaningFee)}
                  </span>
                </div>
                {pricing.discountAmount > 0 && (
                  <div className="flex justify-between text-[#D93A6B] font-semibold">
                    <span>Direct Promo Discount (15%)</span>
                    <span>- {formatINR(pricing.discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-[#2B2F3A]/60">
                  <span>Hospitality GST (18%)</span>
                  <span>{formatINR(pricing.gstAmount)}</span>
                </div>

                <div className="pt-3 border-t border-[#14213D]/10 flex justify-between text-sm sm:text-base font-bold text-[#14213D]">
                  <span>Total before extras</span>
                  <span className="font-sans text-[#14213D]">{formatINR(pricing.grandTotal)}</span>
                </div>
              </div>

              {/* Reserve Button */}
              <button
                onClick={handleReserve}
                className="w-full py-4 bg-[#D93A6B] hover:bg-[#c42f5d] text-white text-xs font-semibold uppercase tracking-wider rounded-[12px] shadow-sm transition-all duration-200 hover:shadow flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>Reserve Residence</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <div className="text-center">
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-medium text-[#2A8CB5] hover:underline inline-flex items-center gap-1.5"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Ask a question on WhatsApp</span>
                </a>
                <p className="text-[11px] text-[#2B2F3A]/50 mt-1">
                  You won't be charged yet · Free cancellation up to 48h
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Similar Stays Row */}
        <div className="mt-20 pt-12 border-t border-[#14213D]/10">
          <div className="mb-8">
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-[#B89B72] mb-1">
              Alternative Options
            </div>
            <h2 className="font-serif text-3xl font-medium text-[#14213D]">
              Similar serviced homes in Bandra
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {similarStays.map((s) => (
              <StayCard key={s.id} stay={s} />
            ))}
          </div>
        </div>
      </div>

      {/* Mobile Sticky Bottom Reserve Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#14213D]/10 p-4 shadow-2xl flex items-center justify-between">
        <div>
          <div className="text-xs text-[#2B2F3A]/60">Total for {nights} nights</div>
          <div className="text-lg font-bold text-[#14213D] font-sans">
            {formatINR(pricing.grandTotal)}
          </div>
        </div>
        <button
          onClick={handleReserve}
          className="px-6 py-3 bg-[#D93A6B] text-white text-xs font-semibold uppercase tracking-wider rounded-[10px] shadow"
        >
          Reserve
        </button>
      </div>

      {/* Full-Screen Lightbox Modal */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between p-4 sm:p-8 animate-in fade-in duration-200">
          {/* Lightbox Header */}
          <div className="flex items-center justify-between text-white pb-4 border-b border-white/10">
            <div>
              <div className="text-xs text-[#B89B72] uppercase tracking-wider font-semibold">
                {stay.name}
              </div>
              <div className="text-xs text-white/60">
                Photo {activePhotoIndex + 1} of {stay.images.length}
              </div>
            </div>

            <button
              onClick={() => setLightboxOpen(false)}
              className="p-2 rounded-full hover:bg-white/10 text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Lightbox Center Image with Nav Arrows */}
          <div className="relative flex-1 flex items-center justify-center p-4">
            <button
              onClick={() =>
                setActivePhotoIndex(
                  activePhotoIndex === 0 ? stay.images.length - 1 : activePhotoIndex - 1
                )
              }
              className="absolute left-2 sm:left-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer z-10"
              aria-label="Previous image"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <img
              src={stay.images[activePhotoIndex]}
              alt={`${stay.name} view ${activePhotoIndex + 1}`}
              className="max-h-[75vh] max-w-[90vw] object-contain rounded-[8px] shadow-2xl transition-all duration-300"
            />

            <button
              onClick={() =>
                setActivePhotoIndex((activePhotoIndex + 1) % stay.images.length)
              }
              className="absolute right-2 sm:right-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer z-10"
              aria-label="Next image"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Thumbnails row at bottom */}
          <div className="flex items-center justify-center gap-2 overflow-x-auto py-2">
            {stay.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActivePhotoIndex(idx)}
                className={`w-14 h-14 rounded-[6px] overflow-hidden border-2 transition-all shrink-0 ${
                  activePhotoIndex === idx ? 'border-[#D93A6B] scale-105' : 'border-transparent opacity-60'
                }`}
              >
                <img src={img} alt="thumb" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
