import React, { useState, useEffect } from 'react';
import { useBooking } from '../context/BookingContext';
import { BrandLogo } from './BrandLogo';
import { Heart, Menu, X, ArrowRight, Tag, SlidersHorizontal } from 'lucide-react';

interface HeaderProps {
  onOpenWishlist: () => void;
  onOpenCompare: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenWishlist, onOpenCompare }) => {
  const { currentRoute, navigateTo, wishlist, compareList } = useBooking();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Stays', path: '/stays' },
    { label: 'Experiences', path: '/experiences' },
    { label: 'Corporate', path: '/corporate' },
    { label: 'List Your Property', path: '/list' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  const handleNavClick = (path: string) => {
    navigateTo(path);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Announcement Bar */}
      <div className="bg-[#14213D] text-[#FAF6F0] py-2 px-4 text-xs font-medium tracking-wide flex items-center justify-center gap-3 transition-colors border-b border-[#FAF6F0]/10">
        <span className="flex items-center gap-1.5 text-[#F8E1E8]">
          <Tag className="w-3.5 h-3.5 text-[#D93A6B]" />
          <span>Limited offer: 15% off on your next stay</span>
        </span>
        <span className="text-[#FAF6F0]/40">·</span>
        <span className="font-mono bg-[#D93A6B]/20 text-[#FAF6F0] px-2 py-0.5 rounded text-[11px] tracking-wider border border-[#D93A6B]/40">
          CONNEKT15
        </span>
        <span className="text-[#FAF6F0]/50 text-[11px] hidden sm:inline">[Confirm terms]</span>
      </div>

      {/* Main Sticky Header */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#FAF6F0]/95 backdrop-blur-md shadow-sm border-b border-[#14213D]/10 py-3.5'
            : 'bg-[#FAF6F0] border-b border-[#14213D]/5 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-6">
            {/* Zone 1: Brand Wordmark */}
            <div
              onClick={() => handleNavClick('/')}
              className="cursor-pointer transition-opacity hover:opacity-90 shrink-0"
              role="button"
              tabIndex={0}
              aria-label="Connekt Homes Home"
            >
              <BrandLogo size="md" variant="dark" />
            </div>

            {/* Zone 2: Navigation Links */}
            <nav className="hidden lg:flex items-center gap-7 text-[13.5px] font-medium tracking-tight text-[#2B2F3A]">
              {navLinks.map((link) => {
                const isActive = currentRoute === link.path || (link.path === '/stays' && currentRoute.startsWith('/stay/'));
                return (
                  <button
                    key={link.path}
                    onClick={() => handleNavClick(link.path)}
                    className={`relative py-1 transition-colors hover:text-[#D93A6B] cursor-pointer whitespace-nowrap ${
                      isActive ? 'text-[#D93A6B] font-semibold' : 'text-[#2B2F3A]/85'
                    }`}
                  >
                    {link.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#D93A6B] rounded-full" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Zone 3: Actions & Book button */}
            <div className="flex items-center gap-3 sm:gap-4 shrink-0">
              {/* Compare Button if items present */}
              {compareList.length > 0 && (
                <button
                  onClick={onOpenCompare}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-[10px] text-xs font-medium text-[#14213D] border border-[#14213D]/20 hover:bg-[#EFE6DA]/60 transition-colors cursor-pointer"
                  title="Compare selected stays"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-[#2A8CB5]" />
                  <span>Compare ({compareList.length})</span>
                </button>
              )}

              {/* Wishlist Button */}
              <button
                onClick={onOpenWishlist}
                className="relative p-2 rounded-[10px] text-[#2B2F3A] hover:bg-[#EFE6DA] transition-colors cursor-pointer"
                aria-label={`Wishlist with ${wishlist.length} saved stays`}
              >
                <Heart className={`w-5 h-5 ${wishlist.length > 0 ? 'fill-[#D93A6B] text-[#D93A6B]' : 'text-[#2B2F3A]'}`} />
                {wishlist.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#D93A6B] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </button>

              {/* Primary Book CTA */}
              <button
                onClick={() => handleNavClick('/stays')}
                className="hidden sm:inline-flex items-center gap-2 bg-[#D93A6B] hover:bg-[#c42f5d] text-white text-xs font-semibold tracking-wider uppercase px-4 py-2.5 rounded-[10px] shadow-sm transition-all duration-200 hover:shadow group cursor-pointer"
              >
                <span>Book a stay</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-[#2B2F3A] hover:bg-[#EFE6DA] rounded-[10px] transition-colors cursor-pointer"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-[#FAF6F0] flex flex-col justify-between p-6 overflow-y-auto lg:hidden animate-in fade-in duration-200">
          <div>
            <div className="flex items-center justify-between pb-6 border-b border-[#14213D]/10">
              <BrandLogo size="md" variant="dark" />
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-full hover:bg-[#EFE6DA] text-[#2B2F3A]"
                aria-label="Close menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="py-8 space-y-4">
              {navLinks.map((link) => (
                <div key={link.path}>
                  <button
                    onClick={() => handleNavClick(link.path)}
                    className="w-full text-left font-serif text-2xl tracking-tight text-[#14213D] py-2 hover:text-[#D93A6B] transition-colors flex items-center justify-between"
                  >
                    <span>{link.label}</span>
                    <ArrowRight className="w-4 h-4 text-[#B89B72]" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-6 border-t border-[#14213D]/10 space-y-4">
            <button
              onClick={() => handleNavClick('/stays')}
              className="w-full py-3.5 bg-[#D93A6B] text-white font-semibold text-sm tracking-wider uppercase rounded-[10px] flex items-center justify-center gap-2 shadow"
            >
              <span>Explore All Stays</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-center text-xs text-[#2B2F3A]/60">
              <span>Bandra West & Pali Hill, Mumbai</span>
              <div className="mt-1 font-serif italic text-sm text-[#14213D]">
                "Homes with a soul."
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
