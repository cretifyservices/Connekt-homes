import React, { createContext, useContext, useState, useEffect } from 'react';
import { Stay, STAYS_DATA } from '../data/stays';

export interface BookingDetails {
  stayId: string;
  checkInDate: string; // YYYY-MM-DD
  checkOutDate: string; // YYYY-MM-DD
  nights: number;
  guests: number;
  extras: {
    earlyCheckIn: boolean;
    lateCheckOut: boolean;
    airportPickup: boolean;
    groceryPack: boolean;
    extraCleaning: boolean;
  };
  promoCode: string;
  discountPercentage: number;
  guestInfo: {
    fullName: string;
    email: string;
    phone: string;
    country: string;
    specialRequests: string;
    idUploaded: boolean;
  };
  paymentMethod: 'upi' | 'card' | 'netbanking' | 'split';
  bookingId?: string;
  createdAt?: string;
}

interface BookingContextType {
  // Navigation / Hash
  currentRoute: string;
  routeParams: Record<string, string>;
  navigateTo: (path: string) => void;

  // Stays & Search
  allStays: Stay[];
  searchDestination: string;
  setSearchDestination: (val: string) => void;
  searchDates: { start: string; end: string };
  setSearchDates: (val: { start: string; end: string }) => void;
  searchGuests: number;
  setSearchGuests: (val: number) => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (stayId: string) => void;
  isWishlisted: (stayId: string) => boolean;

  // Comparison
  compareList: string[];
  toggleCompare: (stayId: string) => void;
  removeFromCompare: (stayId: string) => void;
  clearCompare: () => void;

  // Recently Viewed
  recentlyViewed: string[];
  addRecentlyViewed: (stayId: string) => void;

  // Active Booking
  bookingDetails: BookingDetails;
  updateBookingDetails: (updates: Partial<BookingDetails>) => void;
  updateGuestInfo: (updates: Partial<BookingDetails['guestInfo']>) => void;
  toggleExtra: (key: keyof BookingDetails['extras']) => void;
  applyPromoCode: (code: string) => { success: boolean; message: string };
  calculatePricing: (stay: Stay, details?: BookingDetails) => {
    nightlyRate: number;
    nights: number;
    accommodationTotal: number;
    cleaningFee: number;
    extrasTotal: number;
    subtotal: number;
    discountAmount: number;
    gstAmount: number;
    grandTotal: number;
  };
  confirmBooking: () => string; // returns bookingId
  lastConfirmedBooking: {
    details: BookingDetails;
    stay: Stay;
    pricing: ReturnType<BookingContextType['calculatePricing']>;
  } | null;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const EXTRA_PRICES = {
  earlyCheckIn: 1200,
  lateCheckOut: 1200,
  airportPickup: 1800,
  groceryPack: 1500,
  extraCleaning: 800,
};

export const BookingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Hash Routing
  const [currentRoute, setCurrentRoute] = useState<string>(() => {
    const hash = window.location.hash.replace('#', '') || '/';
    return hash;
  });

  const [routeParams, setRouteParams] = useState<Record<string, string>>({});

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || '/';
      setCurrentRoute(hash);

      // Simple route param matching: /stay/:id
      if (hash.startsWith('/stay/')) {
        const id = hash.replace('/stay/', '').split('?')[0];
        setRouteParams({ id });
      } else {
        setRouteParams({});
      }

      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (path: string) => {
    window.location.hash = path.startsWith('/') ? path : `/${path}`;
  };

  // Search State
  const [searchDestination, setSearchDestination] = useState('Bandra West, Mumbai');
  // Default dates: tomorrow to +3 days
  const today = new Date();
  const defStart = new Date(today);
  defStart.setDate(today.getDate() + 1);
  const defEnd = new Date(today);
  defEnd.setDate(today.getDate() + 4);

  const formatDateStr = (d: Date) => d.toISOString().split('T')[0];

  const [searchDates, setSearchDates] = useState({
    start: formatDateStr(defStart),
    end: formatDateStr(defEnd),
  });
  const [searchGuests, setSearchGuests] = useState(2);

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('connekt_wishlist');
      return stored ? JSON.parse(stored) : ['pali-haven-residence'];
    } catch {
      return ['pali-haven-residence'];
    }
  });

  const toggleWishlist = (stayId: string) => {
    setWishlist((prev) => {
      const updated = prev.includes(stayId) ? prev.filter((id) => id !== stayId) : [...prev, stayId];
      try {
        localStorage.setItem('connekt_wishlist', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const isWishlisted = (stayId: string) => wishlist.includes(stayId);

  // Compare List (up to 3)
  const [compareList, setCompareList] = useState<string[]>([]);
  const toggleCompare = (stayId: string) => {
    setCompareList((prev) => {
      if (prev.includes(stayId)) {
        return prev.filter((id) => id !== stayId);
      }
      if (prev.length >= 3) {
        return [prev[1], prev[2], stayId];
      }
      return [...prev, stayId];
    });
  };
  const removeFromCompare = (stayId: string) => {
    setCompareList((prev) => prev.filter((id) => id !== stayId));
  };
  const clearCompare = () => setCompareList([]);

  // Recently Viewed
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>([]);
  const addRecentlyViewed = (stayId: string) => {
    setRecentlyViewed((prev) => {
      const filtered = prev.filter((id) => id !== stayId);
      return [stayId, ...filtered].slice(0, 5);
    });
  };

  // Booking details state
  const [bookingDetails, setBookingDetails] = useState<BookingDetails>({
    stayId: 'pali-haven-residence',
    checkInDate: formatDateStr(defStart),
    checkOutDate: formatDateStr(defEnd),
    nights: 3,
    guests: 2,
    extras: {
      earlyCheckIn: false,
      lateCheckOut: false,
      airportPickup: false,
      groceryPack: false,
      extraCleaning: false,
    },
    promoCode: '',
    discountPercentage: 0,
    guestInfo: {
      fullName: '',
      email: '',
      phone: '',
      country: 'India',
      specialRequests: '',
      idUploaded: false,
    },
    paymentMethod: 'upi',
  });

  const updateBookingDetails = (updates: Partial<BookingDetails>) => {
    setBookingDetails((prev) => {
      const merged = { ...prev, ...updates };
      // Recalculate nights if dates changed
      if (updates.checkInDate || updates.checkOutDate) {
        const start = new Date(merged.checkInDate);
        const end = new Date(merged.checkOutDate);
        const diffTime = Math.abs(end.getTime() - start.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;
        merged.nights = diffDays;
      }
      return merged;
    });
  };

  const updateGuestInfo = (updates: Partial<BookingDetails['guestInfo']>) => {
    setBookingDetails((prev) => ({
      ...prev,
      guestInfo: { ...prev.guestInfo, ...updates },
    }));
  };

  const toggleExtra = (key: keyof BookingDetails['extras']) => {
    setBookingDetails((prev) => ({
      ...prev,
      extras: {
        ...prev.extras,
        [key]: !prev.extras[key],
      },
    }));
  };

  const applyPromoCode = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    if (trimmed === 'CONNEKT15') {
      setBookingDetails((prev) => ({
        ...prev,
        promoCode: 'CONNEKT15',
        discountPercentage: 15,
      }));
      return { success: true, message: 'Promo code CONNEKT15 applied: 15% discount.' };
    }
    return { success: false, message: 'Invalid or expired promo code.' };
  };

  const calculatePricing = (stay: Stay, details: BookingDetails = bookingDetails) => {
    const nights = Math.max(1, details.nights || 1);
    const nightlyRate = stay.pricePerNight;
    const accommodationTotal = nightlyRate * nights;
    const cleaningFee = stay.cleaningFee;

    let extrasTotal = 0;
    if (details.extras.earlyCheckIn) extrasTotal += EXTRA_PRICES.earlyCheckIn;
    if (details.extras.lateCheckOut) extrasTotal += EXTRA_PRICES.lateCheckOut;
    if (details.extras.airportPickup) extrasTotal += EXTRA_PRICES.airportPickup;
    if (details.extras.groceryPack) extrasTotal += EXTRA_PRICES.groceryPack;
    if (details.extras.extraCleaning) extrasTotal += EXTRA_PRICES.extraCleaning;

    const subtotal = accommodationTotal + cleaningFee + extrasTotal;
    const discountAmount = details.discountPercentage > 0 ? Math.round((accommodationTotal * details.discountPercentage) / 100) : 0;
    const afterDiscount = subtotal - discountAmount;
    const gstAmount = Math.round(afterDiscount * 0.18); // 18% GST standard on luxury hospitality
    const grandTotal = afterDiscount + gstAmount;

    return {
      nightlyRate,
      nights,
      accommodationTotal,
      cleaningFee,
      extrasTotal,
      subtotal,
      discountAmount,
      gstAmount,
      grandTotal,
    };
  };

  const [lastConfirmedBooking, setLastConfirmedBooking] = useState<{
    details: BookingDetails;
    stay: Stay;
    pricing: ReturnType<BookingContextType['calculatePricing']>;
  } | null>(null);

  const confirmBooking = () => {
    const randomHex = Math.floor(100000 + Math.random() * 900000);
    const newBookingId = `CNK-${randomHex}`;
    const stay = STAYS_DATA.find((s) => s.id === bookingDetails.stayId) || STAYS_DATA[0];
    const pricing = calculatePricing(stay, bookingDetails);

    const completedDetails = {
      ...bookingDetails,
      bookingId: newBookingId,
      createdAt: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
    };

    setLastConfirmedBooking({
      details: completedDetails,
      stay,
      pricing,
    });

    return newBookingId;
  };

  return (
    <BookingContext.Provider
      value={{
        currentRoute,
        routeParams,
        navigateTo,
        allStays: STAYS_DATA,
        searchDestination,
        setSearchDestination,
        searchDates,
        setSearchDates,
        searchGuests,
        setSearchGuests,
        wishlist,
        toggleWishlist,
        isWishlisted,
        compareList,
        toggleCompare,
        removeFromCompare,
        clearCompare,
        recentlyViewed,
        addRecentlyViewed,
        bookingDetails,
        updateBookingDetails,
        updateGuestInfo,
        toggleExtra,
        applyPromoCode,
        calculatePricing,
        confirmBooking,
        lastConfirmedBooking,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};

// Formatting utility for INR
export const formatINR = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
};
