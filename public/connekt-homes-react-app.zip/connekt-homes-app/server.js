import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

const distPath = path.join(__dirname, 'dist');
const publicPath = path.join(__dirname, 'public');

app.use(express.static(distPath));
app.use(express.static(publicPath));

// Dedicated download endpoint with Content-Disposition
app.get(['/download', '/api/download-app'], (req, res) => {
  const zipFile = path.join(publicPath, 'connekt-homes-react-app.zip');
  res.download(zipFile, 'connekt-homes-react-app.zip');
});

// Fallback to index.html for SPA hash/history support
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Connekt Homes server listening on port ${PORT}`);
});
