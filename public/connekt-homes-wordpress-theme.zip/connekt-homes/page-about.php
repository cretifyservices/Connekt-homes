<?php
/**
 * Template Name: About Connekt Homes
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Our Story</span>
        <h1 class="page-title">Homes with a soul, crafted for the global traveller.</h1>
        <p class="page-desc">Connekt Homes was founded to bridge the gap between impersonal hotel rooms and unpredictable vacation rentals. Where you stay should feel like your own sanctuary.</p>
    </div>
    <div class="about-hero-img soft-arch" style="margin-bottom: 50px; overflow: hidden; height: 420px;">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Connekt Living Room" style="width: 100%; height: 100%; object-fit: cover;">
    </div>
</div>
<?php get_footer(); ?>
