<?php
/**
 * Template Name: List Your Property
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">For Property Owners</span>
        <h1 class="page-title">Let your home earn with Connekt</h1>
        <p class="page-desc">We partner with discerning apartment owners in Bandra, Pali Hill, and South Mumbai. Enjoy 2-3x traditional residential rental yields with zero day-to-day tenant hassles.</p>
    </div>

    <div class="pillars-grid" style="margin-bottom: 50px;">
        <div class="pillar-card">
            <span class="pillar-num">01</span>
            <h3>Curation & Styling Audit</h3>
            <p>Our interior team assists with styling, linen procurement, and architectural photography.</p>
        </div>
        <div class="pillar-card">
            <span class="pillar-num">02</span>
            <h3>Vetted Premium Guests</h3>
            <p>We list your home across Connekt’s private guest network and international corporate accounts.</p>
        </div>
        <div class="pillar-card">
            <span class="pillar-num">03</span>
            <h3>Hands-Off Net Yields</h3>
            <p>Daily housekeeping, maintenance, and direct monthly bank payouts on the 5th.</p>
        </div>
    </div>

    <div class="contact-form-box">
        <h2>List Your Property for Evaluation</h2>
        <form>
            <div class="form-row">
                <div class="form-col"><label>Owner Name *</label><input type="text"></div>
                <div class="form-col"><label>Phone Number *</label><input type="tel"></div>
            </div>
            <div class="form-row">
                <div class="form-col"><label>Email *</label><input type="email"></div>
                <div class="form-col"><label>Neighborhood in Mumbai</label><input type="text" placeholder="e.g. Pali Hill"></div>
            </div>
            <button type="button" class="btn-primary" style="margin-top: 15px;">Request Property Walkthrough</button>
        </form>
    </div>
</div>
<?php get_footer(); ?>
