<?php
/**
 * Template Name: Experiences & Guide
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Local Curation</span>
        <h1 class="page-title">The Connekt Neighbourhood Guide</h1>
        <p class="page-desc">Our insider journal of where to drink the finest espresso, discover hidden heritage squares, and take sunset strolls along the Arabian Sea.</p>
    </div>

    <div class="guide-grid">
        <div class="guide-card">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/bandra_pali_hill_street.jpg' ); ?>" alt="Subko Coffee">
            <h3>Subko Coffee Roasters & Bakehouse</h3>
            <p>Single-origin roast coffee from tribal estates across the Western Ghats paired with twice-baked podi croissants in a 19th-century cottage.</p>
            <span class="guide-badge">4 min walk from Pali Hill Stays</span>
        </div>
        <div class="guide-card">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_living_room.jpg' ); ?>" alt="Veronica's">
            <h3>Veronica’s Sandwich Shop</h3>
            <p>Housed in the restored St. Jude Bakery, serving legendary house-cured pastrami and natural wines amidst vibrant wall frescoes.</p>
            <span class="guide-badge">2 min walk from Ranwar Atelier</span>
        </div>
        <div class="guide-card">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Carter Road">
            <h3>Carter Road Seafront Promenade</h3>
            <p>A 1.6 km pedestrian walkway facing the open Arabian Sea. Watch local dogs run at twilight and catch cool maritime breezes.</p>
            <span class="guide-badge">1 min walk from Carter Penthouse</span>
        </div>
    </div>
</div>
<?php get_footer(); ?>
