/**
 * Connekt Homes Interactive JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {
    // Time story switcher
    const timeTabs = document.querySelectorAll('.time-tab');
    const storyImg = document.getElementById('day-story-img');
    const storyTitle = document.getElementById('day-story-title');
    const storyDesc = document.getElementById('day-story-desc');

    if (timeTabs.length && storyImg) {
        timeTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                timeTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');

                const newImg = this.getAttribute('data-img');
                const newTitle = this.getAttribute('data-title');
                const newDesc = this.getAttribute('data-desc');

                storyImg.style.opacity = '0.4';
                setTimeout(() => {
                    storyImg.src = newImg;
                    storyTitle.textContent = newTitle;
                    storyDesc.textContent = newDesc;
                    storyImg.style.opacity = '1';
                }, 150);
            });
        });
    }
});
