<?php
/**
 * Template Name: Connekt Homes Front Page
 *
 * @package Connekt_Homes
 */

get_header();
?>

<main id="primary" class="site-main">
    <!-- 1. HERO SECTION -->
    <section class="hero-section">
        <div class="container hero-container">
            <div class="hero-grid">
                <div class="hero-copy">
                    <div class="location-badge">
                        <span class="badge-dot"></span>
                        <span>Bandra West & Pali Hill · Mumbai</span>
                    </div>
                    <h1 class="hero-title">
                        Homes with a soul,<br>
                        <em>wherever you land.</em>
                    </h1>
                    <p class="hero-subtext">
                        Short-term serviced residences for the global traveller. Full kitchens, sunlit living areas, daily housekeeping, and quiet concierge support in Mumbai’s cultural heart.
                    </p>
                    <div class="hero-buttons">
                        <a href="<?php echo esc_url( home_url( '/stays' ) ); ?>" class="btn-primary">
                            <span>Explore Stays</span>
                            <span class="arrow">&rarr;</span>
                        </a>
                        <a href="<?php echo esc_url( home_url( '/experiences' ) ); ?>" class="btn-secondary">
                            Neighbourhood Guide
                        </a>
                    </div>
                </div>

                <div class="hero-visual">
                    <div class="arched-frame soft-arch">
                        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Sunlit serviced apartment living room in Bandra Mumbai">
                        <div class="frame-overlay">
                            <div>
                                <span class="feat-tag">Featured Residence</span>
                                <span class="feat-name">The Arched Haven</span>
                            </div>
                            <span class="feat-loc">Pali Hill</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Elevated Search Card -->
            <div class="search-card-wrapper">
                <form action="<?php echo esc_url( home_url( '/stays' ) ); ?>" method="GET" class="search-card">
                    <div class="search-col">
                        <label>Where</label>
                        <select name="area">
                            <option value="all">All of Bandra West</option>
                            <option value="pali-hill">Pali Hill</option>
                            <option value="pali-village">Pali Village</option>
                            <option value="carter-road">Carter Road</option>
                            <option value="ranwar">Ranwar Village</option>
                        </select>
                    </div>
                    <div class="search-col">
                        <label>Check-in</label>
                        <input type="date" name="checkin" value="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                    </div>
                    <div class="search-col">
                        <label>Check-out</label>
                        <input type="date" name="checkout" value="<?php echo date('Y-m-d', strtotime('+4 days')); ?>">
                    </div>
                    <div class="search-col">
                        <label>Guests</label>
                        <select name="guests">
                            <option value="1">1 Guest</option>
                            <option value="2" selected>2 Guests</option>
                            <option value="4">4 Guests</option>
                            <option value="6">6 Guests</option>
                        </select>
                    </div>
                    <div class="search-action">
                        <button type="submit" class="btn-primary search-btn">Search stays</button>
                    </div>
                </form>
                <div class="trust-chips">
                    <span>· Fully furnished</span>
                    <span>· Daily housekeeping</span>
                    <span>· Keyless self check-in</span>
                    <span>· 24/7 concierge support</span>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. BRAND STATEMENT & EDITORIAL STATS -->
    <section class="section brand-statement-section">
        <div class="container text-center">
            <span class="section-kicker">The Connekt Ethos</span>
            <blockquote class="editorial-quote">
                “We founded Connekt Homes on a simple truth: global travellers do not want sterile hotel boxes. They crave <em>lived-in warmth</em>, authentic neighbourhood rhythms, and the unpretentious sanctuary of an actual home—delivered with flawless hospitality.”
            </blockquote>
            <p class="editorial-sub">Boutique Serviced Living · Curated in Mumbai</p>
            <div class="stats-row">
                <div class="stat-item">
                    <div class="stat-num">4.96 <span class="star">★</span></div>
                    <div class="stat-label">Average Guest Rating [EDIT]</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">100%</div>
                    <div class="stat-label">Verified Residences [EDIT]</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">24 / 7</div>
                    <div class="stat-label">On-Ground Concierge Care [EDIT]</div>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. FEATURED STAYS -->
    <?php get_template_part( 'template-parts/stay-card' ); ?>

    <!-- 4. WHY CONNEKT: FOUR PILLARS -->
    <section class="section why-connekt-section">
        <div class="container">
            <div class="section-header text-center">
                <span class="section-kicker">The Connekt Promise</span>
                <h2 class="section-title">Why travellers choose <em>Connekt</em></h2>
            </div>
            <div class="pillars-grid">
                <div class="pillar-card">
                    <span class="pillar-num">01</span>
                    <h3>Homes, Not Rooms</h3>
                    <p>Separate living rooms, dedicated dining spaces, and complete kitchens so you can cook, entertain, and spread out in comfort.</p>
                </div>
                <div class="pillar-card">
                    <span class="pillar-num">02</span>
                    <h3>Hotel-Grade Care</h3>
                    <p>Spotless daily housekeeping, natural botanical toiletries, crisp 400-thread count cotton sheets, and responsive concierge support.</p>
                </div>
                <div class="pillar-card">
                    <span class="pillar-num">03</span>
                    <h3>Live Like a Local</h3>
                    <p>Immerse yourself in authentic Bandra life. Stroll down leafy lanes to morning bakeries, local fruit stalls, and seaside cafes.</p>
                </div>
                <div class="pillar-card">
                    <span class="pillar-num">04</span>
                    <h3>Stay As Long As You Like</h3>
                    <p>From weekend creative retreats to multi-month corporate relocations with flexible month-to-month terms and GST tax invoicing.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. A DAY AT CONNEKT PINNED STORY -->
    <?php get_template_part( 'template-parts/content-day-at-connekt' ); ?>

    <!-- 6. AMENITIES GRID -->
    <?php get_template_part( 'template-parts/content-amenities' ); ?>

    <!-- 7. NEIGHBOURHOOD / MAP -->
    <?php get_template_part( 'template-parts/content-map' ); ?>

    <!-- 8. GUEST STORIES (NAVY BAND) -->
    <?php get_template_part( 'template-parts/content-stories' ); ?>

    <!-- 9. OFFER BANNER -->
    <?php get_template_part( 'template-parts/content-offer' ); ?>

    <!-- 10. INSTAGRAM GRID -->
    <section class="section instagram-section">
        <div class="container">
            <div class="section-header flex-between">
                <div>
                    <span class="section-kicker">Visual Chronicle</span>
                    <h2 class="section-title">Follow our journey <em>@connekt_homes</em></h2>
                </div>
                <a href="https://www.instagram.com/connekt_homes/" target="_blank" rel="noopener noreferrer" class="btn-secondary">
                    Follow on Instagram ↗
                </a>
            </div>
            <div class="insta-grid">
                <div class="insta-tile"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Connekt Homes Interior"></div>
                <div class="insta-tile"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_bedroom_suite.jpg' ); ?>" alt="Connekt Homes Bedroom"></div>
                <div class="insta-tile"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/bandra_pali_hill_street.jpg' ); ?>" alt="Pali Hill Street"></div>
                <div class="insta-tile"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_kitchen_dining.jpg' ); ?>" alt="Kitchen Island"></div>
                <div class="insta-tile"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_living_room.jpg' ); ?>" alt="Library Salon"></div>
                <div class="insta-tile"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Bandra Living Room"></div>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();
