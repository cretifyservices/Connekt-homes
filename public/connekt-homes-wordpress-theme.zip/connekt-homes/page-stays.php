<?php
/**
 * Template Name: Stays Catalog
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Short-Term Serviced Stays</span>
        <h1 class="page-title">Available Homes in Bandra West</h1>
        <p class="page-desc">Explore handpicked 1 BHK, 2 BHK, and penthouses with hotel care and full kitchens.</p>
    </div>

    <?php get_template_part( 'template-parts/stay-card' ); ?>
</div>
<?php get_footer(); ?>
