<?php
/**
 * Template Name: Careers
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Join Connekt Homes</span>
        <h1 class="page-title">We’re hiring: grow with us</h1>
        <p class="page-desc">Help us redefine boutique hospitality in Mumbai.</p>
    </div>

    <div class="career-card" style="background: white; border: 1px solid rgba(20,33,61,0.1); border-radius: 20px; padding: 40px; margin-bottom: 40px;">
        <span class="badge-hot" style="display: inline-block; margin-bottom: 10px;">Priority Opening</span>
        <h2>Venue Manager – Serviced Residences</h2>
        <p><strong>Location:</strong> Pali Hill & Bandra West, Mumbai · Full-Time [EDIT]</p>
        <p style="margin-top: 15px;">Oversee daily turnover operations and cleanliness audits across Bandra properties. Coordinate digital check-ins, guest arrival hampers, and rapid WhatsApp inquiries.</p>
    </div>
</div>
<?php get_footer(); ?>
