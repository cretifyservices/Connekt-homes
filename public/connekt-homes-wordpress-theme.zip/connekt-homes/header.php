<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23D93A6B'><path d='M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z'/></svg>" />
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Announcement Bar -->
<div class="announcement-bar">
    <div class="announcement-content">
        <span class="announcement-tag">Limited offer: 15% off on your next stay</span>
        <span class="dot-separator">·</span>
        <span class="promo-pill">CONNEKT15</span>
        <span class="terms-note">[Confirm terms]</span>
    </div>
</div>

<!-- Sticky Main Navigation Bar -->
<header id="site-header" class="site-header">
    <div class="container header-inner">
        <!-- Brand Wordmark with Pink Location Pin -->
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-logo" aria-label="Connekt Homes">
            <svg width="180" height="38" viewBox="0 0 190 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                <text x="0" y="20" font-family="'Plus Jakarta Sans', sans-serif" font-size="17.5" font-weight="700" letter-spacing="0.28em" fill="#14213D">CONNEKT</text>
                <text x="122" y="20" font-family="'Plus Jakarta Sans', sans-serif" font-size="17.5" font-weight="700" letter-spacing="0.22em" fill="#14213D">H</text>
                <g transform="translate(138.5, 4.5) scale(0.68)">
                    <path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13 15.87 2 12 2Z" fill="#D93A6B"/>
                    <circle cx="12" cy="9" r="3.2" fill="#FAF6F0"/>
                </g>
                <text x="154" y="20" font-family="'Plus Jakarta Sans', sans-serif" font-size="17.5" font-weight="700" letter-spacing="0.22em" fill="#14213D">MES</text>
                <text x="2" y="36" font-family="'Plus Jakarta Sans', sans-serif" font-size="7" font-weight="500" letter-spacing="0.32em" fill="#6B7280">PREMIUM SERVICED APARTMENTS</text>
            </svg>
        </a>

        <!-- Desktop Navigation -->
        <nav class="main-nav">
            <a href="<?php echo esc_url( home_url( '/stays' ) ); ?>">Stays</a>
            <a href="<?php echo esc_url( home_url( '/experiences' ) ); ?>">Experiences</a>
            <a href="<?php echo esc_url( home_url( '/corporate' ) ); ?>">Corporate</a>
            <a href="<?php echo esc_url( home_url( '/list' ) ); ?>">List Your Property</a>
            <a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a>
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a>
        </nav>

        <!-- Right Action Buttons -->
        <div class="header-actions">
            <a href="<?php echo esc_url( home_url( '/stays' ) ); ?>" class="btn-primary">
                <span>Book a stay</span>
                <span class="arrow">&rarr;</span>
            </a>
            <button id="mobile-menu-toggle" class="mobile-menu-btn" aria-label="Toggle navigation">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</header>
