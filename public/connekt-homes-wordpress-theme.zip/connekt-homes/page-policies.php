<?php
/**
 * Template Name: Policies
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Governance</span>
        <h1 class="page-title">Policies & Guest Standards</h1>
    </div>
    <div style="background: white; border-radius: 20px; padding: 40px; border: 1px solid rgba(20,33,61,0.1);">
        <h3>Cancellation & Refund Framework [EDIT]</h3>
        <p>Full refund (100%) up to 48 hours prior to check-in. Cancellations within 48 hours receive a 50% refund on unstayed nights.</p>
        <h3 style="margin-top: 25px;">House Rules & Quiet Hours [EDIT]</h3>
        <p>Quiet hours observed from 10:30 PM to 7:00 AM. Strictly non-smoking interiors. Verified government photo ID required.</p>
    </div>
</div>
<?php get_footer(); ?>
