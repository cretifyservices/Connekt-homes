<?php
/**
 * Single Stay Template
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="stay-detail-container container">
    <div class="stay-header">
        <span class="section-kicker">Pali Hill · 2 BHK</span>
        <h1 class="stay-title"><?php the_title(); ?></h1>
        <p class="stay-meta">★ 4.97 (48 reviews) · Up to 4 guests · 2 bedrooms · 2 bathrooms · 1,130 sq ft</p>
    </div>

    <div class="stay-gallery-grid">
        <div class="gallery-main">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Main Photo">
        </div>
        <div class="gallery-thumbs">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_bedroom_suite.jpg' ); ?>" alt="Bedroom">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_kitchen_dining.jpg' ); ?>" alt="Kitchen">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_living_room.jpg' ); ?>" alt="Living Room">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/bandra_pali_hill_street.jpg' ); ?>" alt="Street">
        </div>
    </div>

    <div class="stay-content-layout">
        <div class="stay-main-info">
            <div class="concierge-box">
                <strong>On-Ground Concierge Note</strong>
                <p>Our on-ground Pali Hill host is available 8 AM to 10 PM. Fresh local sourdough and pour-over coffee beans await in the pantry on arrival.</p>
            </div>

            <h2>About this home</h2>
            <p>Tucked away along the serene bougainvillea-framed streets of Pali Hill, this expansive two-bedroom apartment offers a sanctuary of calm amidst Mumbai’s creative pulse. Featuring tall arched floor-to-ceiling glass doors, natural travertine accents, custom fluted oak cabinetry, and an open layout bathed in gentle morning light.</p>

            <h2>Where you'll sleep</h2>
            <div class="sleeping-grid">
                <div class="sleeping-card">
                    <h4>Primary Suite</h4>
                    <p>King bed · 100% Belgian flax linen, ergonomic mattress, ensuite walk-in rain shower</p>
                </div>
                <div class="sleeping-card">
                    <h4>Guest Suite</h4>
                    <p>Queen bed · Custom oak frame, blackout drapes, quiet courtyard garden views</p>
                </div>
            </div>

            <h2>House rules & Cancellation</h2>
            <ul class="rules-list">
                <li>Check-in: 3:00 PM onwards / Check-out: 11:00 AM</li>
                <li>Strictly non-smoking interior</li>
                <li>Government ID required for all guests prior to keycode dispatch [EDIT]</li>
                <li>Flexible cancellation: Full refund up to 48 hours prior to check-in</li>
            </ul>
        </div>

        <div class="stay-booking-sidebar">
            <div class="booking-card">
                <div class="booking-rate"><strong>₹9,800</strong> <span>/ night</span></div>
                <form action="<?php echo esc_url( home_url( '/checkout' ) ); ?>" method="GET" class="booking-form">
                    <div class="form-group">
                        <label>Check-in / Check-out</label>
                        <input type="text" value="3 nights (Flexible dates)" readonly>
                    </div>
                    <div class="form-group">
                        <label>Guests</label>
                        <input type="text" value="2 Guests" readonly>
                    </div>
                    <div class="price-breakdown">
                        <div><span>₹9,800 × 3 nights</span> <span>₹29,400</span></div>
                        <div><span>Housekeeping fee</span> <span>₹1,500</span></div>
                        <div><span>GST (18%)</span> <span>₹5,562</span></div>
                        <div class="total-row"><span>Total</span> <strong>₹36,462</strong></div>
                    </div>
                    <button type="submit" class="btn-primary full-width">Reserve Residence</button>
                    <p class="booking-note">You won't be charged yet · Free cancellation</p>
                </form>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
