<?php
/**
 * Template Name: Checkout Flow
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="checkout-header text-center">
        <span class="section-kicker">Guaranteed Reservation</span>
        <h1 class="page-title">Complete Your Booking</h1>
        <p class="page-desc">3-step encrypted checkout. Valid government ID required at check-in [EDIT].</p>
    </div>

    <div class="checkout-layout">
        <div class="checkout-form-box">
            <h3>01. Guest Details</h3>
            <div class="form-row">
                <div class="form-col"><label>Full Name *</label><input type="text" placeholder="e.g. Swastik Sharma"></div>
                <div class="form-col"><label>Email Address *</label><input type="email" placeholder="swastik@example.com"></div>
            </div>
            <div class="form-row">
                <div class="form-col"><label>Phone / WhatsApp *</label><input type="tel" placeholder="+91 98XXX XXXXX"></div>
                <div class="form-col"><label>Country</label><input type="text" value="India"></div>
            </div>

            <h3 style="margin-top: 30px;">02. Concierge Additions</h3>
            <label class="checkbox-item"><input type="checkbox"> Early Check-in from 11 AM (+₹1,200)</label>
            <label class="checkbox-item"><input type="checkbox"> Airport Chauffeur Transfer (+₹1,800)</label>
            <label class="checkbox-item"><input type="checkbox"> Artisanal Welcome Pantry Hamper (+₹1,500)</label>

            <h3 style="margin-top: 30px;">03. Payment Simulation</h3>
            <label class="radio-item"><input type="radio" name="pay" checked> Instant UPI (Google Pay, PhonePe, Paytm)</label>
            <label class="radio-item"><input type="radio" name="pay"> Credit / Debit Card (Zero international markup)</label>
            <label class="radio-item"><input type="radio" name="pay"> Pay 30% Now, Balance at Check-in</label>

            <a href="<?php echo esc_url( home_url( '/confirmed' ) ); ?>" class="btn-primary" style="margin-top: 30px; display: block; text-align: center;">
                Confirm Reservation &rarr;
            </a>
        </div>

        <div class="checkout-summary-box">
            <h3>Stay Summary</h3>
            <p><strong>The Arched Haven at Pali Hill</strong></p>
            <p>Pali Hill, Bandra West, Mumbai</p>
            <hr style="margin: 15px 0; border: none; border-top: 1px solid rgba(20,33,61,0.1);">
            <div class="price-breakdown">
                <div><span>Accommodation (3 nights)</span> <span>₹29,400</span></div>
                <div><span>Housekeeping</span> <span>₹1,500</span></div>
                <div><span>GST (18%)</span> <span>₹5,562</span></div>
                <div class="total-row"><span>Total</span> <strong>₹36,462</strong></div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
