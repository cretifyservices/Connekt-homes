<?php
get_header();
?>
<div class="container page-container text-center" style="padding: 100px 20px;">
    <span class="section-kicker">Page Not Found · 404</span>
    <h1 class="page-title">You have wandered off the map</h1>
    <p class="page-desc">Return to our Bandra home to explore available short-term stays.</p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-primary" style="margin-top: 20px; display: inline-block;">Return Home</a>
</div>
<?php
get_footer();
