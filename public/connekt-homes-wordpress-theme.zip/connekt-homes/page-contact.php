<?php
/**
 * Template Name: Contact
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Get in Touch</span>
        <h1 class="page-title">We are here to welcome you</h1>
        <p class="page-desc">Whether inquiring about an upcoming reservation, long-term corporate arrangement, or listing your Bandra home, our hospitality team is at your service.</p>
    </div>
    <div class="contact-form-box">
        <h2>Send a Message</h2>
        <form>
            <div class="form-row">
                <div class="form-col"><label>Your Name *</label><input type="text"></div>
                <div class="form-col"><label>Email *</label><input type="email"></div>
            </div>
            <div class="form-group" style="margin-top: 15px;">
                <label>Message *</label>
                <textarea rows="4" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid rgba(20,33,61,0.15);"></textarea>
            </div>
            <button type="button" class="btn-primary" style="margin-top: 15px;">Send Concierge Message</button>
        </form>
    </div>
</div>
<?php get_footer(); ?>
