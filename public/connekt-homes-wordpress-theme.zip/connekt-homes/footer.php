<?php
/**
 * Connekt Homes Footer Template
 *
 * @package Connekt_Homes
 */
?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Brand Column -->
            <div class="footer-col brand-col">
                <div class="footer-logo">
                    <svg width="180" height="38" viewBox="0 0 190 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <text x="0" y="20" font-family="'Plus Jakarta Sans', sans-serif" font-size="17.5" font-weight="700" letter-spacing="0.28em" fill="#FAF6F0">CONNEKT</text>
                        <text x="122" y="20" font-family="'Plus Jakarta Sans', sans-serif" font-size="17.5" font-weight="700" letter-spacing="0.22em" fill="#FAF6F0">H</text>
                        <g transform="translate(138.5, 4.5) scale(0.68)">
                            <path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13 15.87 2 12 2Z" fill="#D93A6B"/>
                            <circle cx="12" cy="9" r="3.2" fill="#14213D"/>
                        </g>
                        <text x="154" y="20" font-family="'Plus Jakarta Sans', sans-serif" font-size="17.5" font-weight="700" letter-spacing="0.22em" fill="#FAF6F0">MES</text>
                        <text x="2" y="36" font-family="'Plus Jakarta Sans', sans-serif" font-size="7" font-weight="500" letter-spacing="0.32em" fill="#D1D5DB">PREMIUM SERVICED APARTMENTS</text>
                    </svg>
                </div>
                <p class="footer-tagline">“Homes with a soul. Short-term stays for the global traveller.”</p>
                <p class="footer-desc">Curated serviced residences in Mumbai’s most beloved neighborhoods. Hotel-grade care with the warmth and privacy of your own home.</p>
                <div class="footer-social">
                    <a href="https://www.instagram.com/connekt_homes/" target="_blank" rel="noopener noreferrer" class="social-badge">
                        <span>@connekt_homes</span>
                        <span>↗</span>
                    </a>
                </div>
            </div>

            <!-- Explore Links -->
            <div class="footer-col">
                <h4 class="footer-heading">Explore</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( home_url( '/stays' ) ); ?>">All Serviced Stays</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/experiences' ) ); ?>">Neighbourhood Guide</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/corporate' ) ); ?>">Corporate & Long Stays</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/list' ) ); ?>">List Your Property</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">Our Story & Values</a></li>
                </ul>
            </div>

            <!-- Company Links -->
            <div class="footer-col">
                <h4 class="footer-heading">Company</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( home_url( '/careers' ) ); ?>">We’re Hiring <span class="badge-hot">HOT</span></a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact & Concierge</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/policies' ) ); ?>">House Rules & Policies</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/policies' ) ); ?>">Cancellation Terms</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/policies' ) ); ?>">Privacy & Data</a></li>
                </ul>
            </div>

            <!-- Concierge Desk -->
            <div class="footer-col">
                <h4 class="footer-heading">Concierge Desk</h4>
                <div class="contact-details">
                    <p>📍 Pali Hill & Bandra West, Mumbai 400050 [EDIT]</p>
                    <p>📞 <a href="https://wa.me/919800000000">+91 98XXX XXXXX [EDIT]</a></p>
                    <p>✉️ <a href="mailto:stays@connekthomes.com">stays@connekthomes.com [EDIT]</a></p>
                    <p class="hours-text">Desk hours: 8:00 AM – 10:00 PM IST</p>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; <?php echo date( 'Y' ); ?> Connekt Homes Hospitality LLP. All rights reserved. [EDIT: GST Registration Number]</p>
            <p class="footer-trust">Verified Serviced Residences · Crafted in Bandra</p>
        </div>
    </div>
</footer>

<!-- Floating WhatsApp Action -->
<aside class="floating-whatsapp" aria-label="WhatsApp Concierge">
    <a href="https://wa.me/919800000000?text=Hello%20Connekt%20Concierge!%20I%20am%20inquiring%20about%20booking%20a%20serviced%20stay." target="_blank" rel="noopener noreferrer" class="whatsapp-btn" aria-label="WhatsApp Concierge">
        <svg viewBox="0 0 24 24" width="28" height="28" fill="white"><path d="M12 2C6.48 2 2 6.48 2 12C2 13.85 2.5 15.58 3.38 17.07L2 22L7.07 20.64C8.52 21.5 10.2 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM16.63 16.5C16.42 17.08 15.35 17.61 14.88 17.69C14.41 17.76 13.8 17.79 11.75 16.94C9.17 15.86 7.5 13.25 7.37 13.08C7.25 12.92 6.33 11.7 6.33 10.43C6.33 9.17 6.98 8.55 7.21 8.31C7.44 8.07 7.71 8.02 7.92 8.02C8.13 8.02 8.34 8.02 8.52 8.03C8.71 8.04 8.96 7.97 9.19 8.52C9.42 9.07 9.99 10.45 10.05 10.59C10.12 10.73 10.16 10.9 10.06 11.08C9.97 11.27 9.9 11.36 9.75 11.53C9.6 11.7 9.47 11.83 9.32 12.01C9.16 12.18 9 12.37 9.18 12.68C9.37 12.99 10.02 14.05 10.98 14.91C12.22 16.02 13.23 16.37 13.56 16.51C13.89 16.65 14.07 16.62 14.25 16.41C14.43 16.2 15.02 15.51 15.23 15.21C15.44 14.91 15.65 14.96 15.93 15.07C16.21 15.17 17.69 15.9 18 16.05C18.31 16.2 18.52 16.28 18.59 16.4C18.67 16.52 18.67 17.11 18.46 17.69L16.63 16.5Z"/></svg>
    </a>
</aside>

<?php wp_footer(); ?>
</body>
</html>
