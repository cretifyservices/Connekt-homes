<?php
/**
 * Template Name: Booking Confirmation
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container text-center">
    <div class="confirmed-card">
        <div class="check-icon">✓</div>
        <span class="section-kicker">Reservation Confirmed</span>
        <h1 class="page-title">We look forward to hosting you</h1>
        <p class="page-desc">Booking Reference: <strong>CNK-829143</strong>. Digital keycode instructions have been dispatched.</p>
        <div class="confirmed-actions">
            <a href="https://wa.me/919800000000" class="btn-secondary">Share on WhatsApp</a>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-primary">Return to Homepage</a>
        </div>
    </div>
</div>
<?php get_footer(); ?>
