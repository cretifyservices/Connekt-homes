# Connekt Homes – WordPress Theme

A premium, production-grade WordPress theme designed specifically for **Connekt Homes** (`@connekt_homes`), a luxury serviced apartment brand for short-term stays in Bandra & Pali Village, Mumbai.

## Theme Architecture & Contents
- `style.css`: Theme metadata header, color palette CSS variables, typography rules, soft arch border utilities, and responsive layout.
- `screenshot.png`: High-resolution theme preview for WordPress Admin.
- `functions.php`: Enqueues Google Fonts (Newsreader + Plus Jakarta Sans), registers primary/footer menus, and registers the custom post type for `stay` (Serviced Apartments).
- `header.php`: Announcement bar with CONNEKT15 promo code, exact SVG wordmark with pink location pin, navigation bar, and primary CTA.
- `footer.php`: Deep navy editorial footer, navigation columns, concierge desk details, WhatsApp floating button.
- `front-page.php`: Full homepage layout implementing all 14 brand sections:
  1. Hero with soft-arched window visual
  2. Editorial brand statement with 3 stats
  3. Featured residences cards
  4. Four Pillars ("Homes, not rooms", "Hotel-grade care", "Live like a local", "Stay as long as you like")
  5. A Day at Connekt pinned time switcher
  6. Standard amenities grid
  7. Neighbourhood proximity map
  8. Navy band guest stories
  9. Offer banner with copyable promo code
  10. Instagram 6-tile grid (@connekt_homes)
- `template-parts/`: Modular sub-templates for clean code maintenance.
- `page-stays.php`: Stays catalog and search results.
- `single-stay.php`: Stay detail template with photo gallery, room specs, and sticky booking card.
- `page-checkout.php`: 3-step checkout flow (Guest info, Extras, Payment options).
- `page-confirmed.php`: Confirmation page with booking ID and WhatsApp share.
- `page-experiences.php`: Local neighbourhood guide.
- `page-corporate.php`: Corporate & long stays with inquiry form.
- `page-list-property.php`: Owner onboarding page with yield calculator.
- `page-about.php`, `page-careers.php`, `page-contact.php`, `page-policies.php`, `404.php`.
- `assets/images/`: 5 high-resolution architectural interior and street photography assets.

## WordPress Installation Instructions
1. In your WordPress admin dashboard, go to **Appearance > Themes**.
2. Click **Add New Theme**, then **Upload Theme**.
3. Choose this `connekt-homes-wordpress-theme.zip` file and click **Install Now**.
4. Click **Activate**.
5. Set your homepage under **Settings > Reading > A static page** and select a page using the *Front Page* template.
