<?php
/**
 * Connekt Homes Theme Functions & Definitions
 *
 * @package Connekt_Homes
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function connekt_homes_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'gallery', 'caption' ) );
    add_theme_support( 'responsive-embeds' );

    register_nav_menus( array(
        'primary' => __( 'Primary Header Menu', 'connekt-homes' ),
        'footer'  => __( 'Footer Menu', 'connekt-homes' ),
    ) );
}
add_action( 'after_setup_theme', 'connekt_homes_setup' );

function connekt_homes_scripts() {
    // Google Fonts
    wp_enqueue_style( 'connekt-fonts', 'https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,300..600;1,6..72,300..600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap', array(), null );
    
    // Main Theme Stylesheet
    wp_enqueue_style( 'connekt-main-style', get_stylesheet_uri(), array(), '1.0.0' );
    wp_enqueue_style( 'connekt-theme-custom', get_template_directory_uri() . '/assets/css/theme.css', array(), '1.0.0' );

    // Main Theme JavaScript
    wp_enqueue_script( 'connekt-main-js', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'connekt_homes_scripts' );

// Register Custom Post Type for Stays / Serviced Apartments
function connekt_register_stays_cpt() {
    $labels = array(
        'name'                  => _x( 'Serviced Stays', 'Post type general name', 'connekt-homes' ),
        'singular_name'         => _x( 'Serviced Stay', 'Post type singular name', 'connekt-homes' ),
        'menu_name'             => _x( 'Stays', 'Admin Menu text', 'connekt-homes' ),
        'add_new'               => __( 'Add New Stay', 'connekt-homes' ),
        'add_new_item'          => __( 'Add New Serviced Stay', 'connekt-homes' ),
        'edit_item'             => __( 'Edit Stay', 'connekt-homes' ),
        'all_items'             => __( 'All Stays', 'connekt-homes' ),
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'menu_icon'          => 'dashicons-building',
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'rewrite'            => array( 'slug' => 'stay' ),
        'show_in_rest'       => true,
    );
    register_post_type( 'stay', $args );
}
add_action( 'init', 'connekt_register_stays_cpt' );
