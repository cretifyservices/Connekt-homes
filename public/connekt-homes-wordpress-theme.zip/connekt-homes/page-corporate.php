<?php
/**
 * Template Name: Corporate & Long Stays
 *
 * @package Connekt_Homes
 */
get_header();
?>
<div class="page-container container">
    <div class="page-header">
        <span class="section-kicker">Executive Living</span>
        <h1 class="page-title">Corporate & Extended Stays in Bandra</h1>
        <p class="page-desc">Eliminate hotel fatigue for visiting founders, consultants, and relocated executive teams. Fully serviced residential apartments designed for deep focus and restorative downtime.</p>
    </div>

    <div class="pillars-grid" style="margin-bottom: 50px;">
        <div class="pillar-card">
            <h3>300 Mbps Fiber WiFi</h3>
            <p>Unthrottled mesh network, ergonomic workstations, and silent inverter generator failover.</p>
        </div>
        <div class="pillar-card">
            <h3>Corporate GST Invoicing</h3>
            <p>Consolidated corporate monthly billing with compliant GST tax input credits.</p>
        </div>
        <div class="pillar-card">
            <h3>Preferential Monthly Pricing</h3>
            <p>Substantial tiered tariff discounts for 14+ night bookings, flexible rolling extensions.</p>
        </div>
    </div>

    <div class="contact-form-box">
        <h2>Request an Executive Proposal</h2>
        <form>
            <div class="form-row">
                <div class="form-col"><label>Company Name *</label><input type="text"></div>
                <div class="form-col"><label>Contact Person *</label><input type="text"></div>
            </div>
            <div class="form-row">
                <div class="form-col"><label>Work Email *</label><input type="email"></div>
                <div class="form-col"><label>Phone / WhatsApp *</label><input type="tel"></div>
            </div>
            <button type="button" class="btn-primary" style="margin-top: 15px;">Submit Corporate Inquiry</button>
        </form>
    </div>
</div>
<?php get_footer(); ?>
