<?php
/**
 * Guest Stories Navy Band Template Part
 */
?>
<section class="section guest-stories-section">
    <div class="container">
        <div class="section-header">
            <span class="section-kicker" style="color: #B89B72;">Guest Experiences</span>
            <h2 class="section-title" style="color: #FAF6F0;">Stories from the <em style="color: #F8E1E8;">global traveller</em></h2>
        </div>

        <div class="stories-box">
            <div class="story-author">
                <div class="author-avatar">SR</div>
                <div class="author-info">
                    <h4>Siddharth & Rhea Rao</h4>
                    <p class="role">Creative Directors & Filmmakers [EDIT]</p>
                    <p class="stayed">The Arched Haven at Pali Hill · 60 nights</p>
                </div>
            </div>
            <div class="story-quote">
                <blockquote>
                    “We had a two-month production schedule across Mehboob Studios and Bandra locations. Connekt gave us a home where we could hold script readings in natural sunlight and unwind with quiet tea on the balcony after 14-hour days.”
                </blockquote>
                <p class="compliance-note">
                    [Notice: Testimonial details are representative placeholders. Use real guest names and photos only with their written permission]
                </p>
            </div>
        </div>
    </div>
</section>
