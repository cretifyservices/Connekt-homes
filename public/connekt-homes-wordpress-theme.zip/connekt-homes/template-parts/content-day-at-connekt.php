<?php
/**
 * A Day at Connekt Pinned Story Template Part
 */
?>
<section class="section day-at-connekt-section">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-kicker">The Living Rhythm</span>
            <h2 class="section-title">A day at <em>Connekt</em></h2>
            <p class="section-sub">Experience how our serviced residences transform through the day—from calm sunlit mornings to twilight ease.</p>
        </div>

        <div class="day-story-card">
            <div class="story-visual">
                <img id="day-story-img" src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="Day at Connekt">
            </div>
            <div class="story-info">
                <div class="time-tabs">
                    <button class="time-tab active" data-time="morning" data-img="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" data-title="Morning Awakening" data-desc="Soft golden morning sunlight pours through the tall arched casement windows. Pour-over specialty coffee from Subko Roasters brews in the kitchen as Pali Hill bird calls echo outside.">08:00 AM</button>
                    <button class="time-tab" data-time="afternoon" data-img="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_living_room.jpg' ); ?>" data-title="Uninterrupted Flow" data-desc="A dedicated oak workstation, acoustic sound-insulation, and seamless 300 Mbps fiber connectivity. Quiet daily housekeeping has already swept through while you took a client call.">02:30 PM</button>
                    <button class="time-tab" data-time="evening" data-img="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_bedroom_suite.jpg' ); ?>" data-title="Twilight Sanctuary" data-desc="Warm brass sconces dim to an amber glow. Crisp Belgian linen sheets, gentle ocean breezes from Carter Road, and complete serenity away from the metropolis.">08:00 PM</button>
                </div>
                <h3 id="day-story-title">Morning Awakening</h3>
                <p id="day-story-desc">Soft golden morning sunlight pours through the tall arched casement windows. Pour-over specialty coffee from Subko Roasters brews in the kitchen as Pali Hill bird calls echo outside.</p>
                <div class="story-meta">
                    <div><span>Natural Illumination:</span> <strong>Diffused East Sun</strong></div>
                    <div><span>Sound Environment:</span> <strong>Quiet Village Birdsong</strong></div>
                    <div><span>Concierge:</span> <strong style="color: #9DB5A0;">On-Call & Discreet</strong></div>
                </div>
            </div>
        </div>
    </div>
</section>
