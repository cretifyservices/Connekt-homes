<?php
/**
 * Template part for displaying featured stays
 */
?>
<section class="section featured-stays-section">
    <div class="container">
        <div class="section-header flex-between">
            <div>
                <span class="section-kicker">Handpicked Collections</span>
                <h2 class="section-title">Featured <em>residences</em></h2>
            </div>
            <a href="<?php echo esc_url( home_url( '/stays' ) ); ?>" class="btn-secondary">
                View All Stays &rarr;
            </a>
        </div>

        <div class="stays-grid">
            <!-- Stay 1 -->
            <article class="stay-card">
                <div class="card-img-wrap">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero_apartment_mumbai.jpg' ); ?>" alt="The Arched Haven at Pali Hill">
                    <span class="card-badge">Superhost Curated</span>
                </div>
                <div class="card-content">
                    <div class="card-meta">
                        <span class="card-area">Pali Hill · 2 BHK</span>
                        <span class="card-rating">★ 4.97 (48)</span>
                    </div>
                    <h3 class="card-title">The Arched Haven at Pali Hill</h3>
                    <p class="card-specs">Up to 4 guests · 2 beds · 1,130 sq ft</p>
                    <div class="card-footer">
                        <div class="card-price"><strong>₹9,800</strong> / night</div>
                        <a href="<?php echo esc_url( home_url( '/stay/pali-haven-residence' ) ); ?>" class="card-link">Explore &rarr;</a>
                    </div>
                </div>
            </article>

            <!-- Stay 2 -->
            <article class="stay-card">
                <div class="card-img-wrap">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_living_room.jpg' ); ?>" alt="The Curator's Flat at Pali Village">
                    <span class="card-badge">1 BHK</span>
                </div>
                <div class="card-content">
                    <div class="card-meta">
                        <span class="card-area">Pali Village · 1 BHK</span>
                        <span class="card-rating">★ 4.95 (62)</span>
                    </div>
                    <h3 class="card-title">The Curator's Flat at Pali Village</h3>
                    <p class="card-specs">Up to 2 guests · 1 bed · 730 sq ft</p>
                    <div class="card-footer">
                        <div class="card-price"><strong>₹7,200</strong> / night</div>
                        <a href="<?php echo esc_url( home_url( '/stay/pali-village-curators-flat' ) ); ?>" class="card-link">Explore &rarr;</a>
                    </div>
                </div>
            </article>

            <!-- Stay 3 -->
            <article class="stay-card">
                <div class="card-img-wrap">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_bedroom_suite.jpg' ); ?>" alt="Ranwar Village Atelier Suite">
                    <span class="card-badge">Studio</span>
                </div>
                <div class="card-content">
                    <div class="card-meta">
                        <span class="card-area">Ranwar Village · Studio</span>
                        <span class="card-rating">★ 4.92 (39)</span>
                    </div>
                    <h3 class="card-title">Ranwar Village Atelier Suite</h3>
                    <p class="card-specs">Up to 2 guests · 1 bed · 515 sq ft</p>
                    <div class="card-footer">
                        <div class="card-price"><strong>₹5,500</strong> / night</div>
                        <a href="<?php echo esc_url( home_url( '/stay/ranwar-heritage-atelier' ) ); ?>" class="card-link">Explore &rarr;</a>
                    </div>
                </div>
            </article>

            <!-- Stay 4 -->
            <article class="stay-card">
                <div class="card-img-wrap">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/apartment_kitchen_dining.jpg' ); ?>" alt="The Coastal Penthouse at Carter Road">
                    <span class="card-badge">3 BHK Penthouse</span>
                </div>
                <div class="card-content">
                    <div class="card-meta">
                        <span class="card-area">Carter Road · Penthouse</span>
                        <span class="card-rating">★ 4.99 (34)</span>
                    </div>
                    <h3 class="card-title">The Coastal Penthouse at Carter Road</h3>
                    <p class="card-specs">Up to 6 guests · 3 beds · 1,990 sq ft</p>
                    <div class="card-footer">
                        <div class="card-price"><strong>₹16,800</strong> / night</div>
                        <a href="<?php echo esc_url( home_url( '/stay/carter-road-coastal-penthouse' ) ); ?>" class="card-link">Explore &rarr;</a>
                    </div>
                </div>
            </article>
        </div>
    </div>
</section>
