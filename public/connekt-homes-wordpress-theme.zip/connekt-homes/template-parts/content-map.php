<?php
/**
 * Neighbourhood Map Template Part
 */
?>
<section class="section map-section">
    <div class="container">
        <div class="section-header flex-between">
            <div>
                <span class="section-kicker">Bandra West Enclave</span>
                <h2 class="section-title">A neighbourhood to <em>wander</em></h2>
                <p class="section-sub">Tree-canopied lanes, heritage Portuguese villages, artisanal coffee roasters, and the Arabian Sea promenade—all within walking reach.</p>
            </div>
        </div>

        <div class="map-layout">
            <div class="map-visual-box">
                <div class="map-header">
                    <span>🧭 Bandra West Serviced Stays</span>
                    <span>19.0600° N, 72.8300° E</span>
                </div>
                <div class="map-graphic">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/bandra_pali_hill_street.jpg' ); ?>" alt="Bandra Pali Hill Neighborhood">
                    <div class="map-pin-overlay">
                        <div class="pin" style="top: 35%; left: 45%;">📍 Pali Hill (₹9,800)</div>
                        <div class="pin" style="top: 55%; left: 52%;">📍 Pali Village (₹7,200)</div>
                        <div class="pin" style="top: 65%; left: 30%;">📍 Carter Road (₹16,800)</div>
                    </div>
                </div>
            </div>
            <div class="map-guide-box">
                <span class="section-kicker">Local Proximity</span>
                <h3>Pali Hill & Village</h3>
                <p>Bandra's green sanctuary celebrated for bougainvillea-framed villas and quiet cafes.</p>
                <div class="proximity-list">
                    <div class="prox-item">
                        <span>Subko Coffee Roasters</span>
                        <span class="walk-badge">4 min walk</span>
                    </div>
                    <div class="prox-item">
                        <span>Pali Bhavan Dining</span>
                        <span class="walk-badge">7 min walk</span>
                    </div>
                    <div class="prox-item">
                        <span>Carter Road Promenade</span>
                        <span class="walk-badge">12 min walk</span>
                    </div>
                    <div class="prox-item">
                        <span>Veronica's Deli & Bakery</span>
                        <span class="walk-badge">5 min walk</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
