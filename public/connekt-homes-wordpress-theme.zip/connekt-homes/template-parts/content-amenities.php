<?php
/**
 * Amenities Grid Template Part
 */
?>
<section class="section amenities-section">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-kicker">Standard In Every Residence</span>
            <h2 class="section-title">Hotel comforts, <em>home warmth</em></h2>
            <p class="section-sub">Every Connekt home comes thoroughly equipped with everything modern travellers require to work, cook, rest, and entertain effortlessly.</p>
        </div>

        <div class="amenities-grid">
            <div class="amenity-card">
                <div class="amenity-icon">📶</div>
                <h3>300 Mbps Fiber WiFi</h3>
                <p>Dedicated dual-band fiber with backup power failover for seamless remote work.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">🍳</div>
                <h3>Full Gourmet Kitchen</h3>
                <p>Induction hob, microwave, refrigerator, artisanal ceramics & cookware.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">❄️</div>
                <h3>Whisper-Quiet AC</h3>
                <p>Inverter climate control in all bedrooms and living spaces.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">💻</div>
                <h3>Ergonomic Workspace</h3>
                <p>Solid oak desk, ergonomic seating, and warm task lighting.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">✨</div>
                <h3>Daily Housekeeping</h3>
                <p>Unobtrusive fresh linen service, sanitisation, and trash clearing.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">🔑</div>
                <h3>Keyless Smart Check-in</h3>
                <p>Encrypted digital pin lock for effortless late or early arrivals.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">📺</div>
                <h3>4K Smart TV & Audio</h3>
                <p>Ultra HD streaming setup with Netflix, Prime, and soundbar.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">🕒</div>
                <h3>24/7 Concierge Support</h3>
                <p>Local Mumbai hospitality team on WhatsApp for any request.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">🛡️</div>
                <h3>Gated Security</h3>
                <p>Round-the-clock building personnel and CCTV in common corridors.</p>
            </div>
            <div class="amenity-card">
                <div class="amenity-icon">☕</div>
                <h3>Local Provisioning</h3>
                <p>Complimentary artisanal tea, specialty coffee, and mineral water.</p>
            </div>
        </div>
    </div>
</section>
