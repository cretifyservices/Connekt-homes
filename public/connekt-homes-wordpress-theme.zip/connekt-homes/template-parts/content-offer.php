<?php
/**
 * Offer Banner Template Part
 */
?>
<section class="section offer-section">
    <div class="container">
        <div class="offer-card">
            <div class="offer-left">
                <div class="scallop-badge">
                    <span>SAVE</span>
                    <strong>15%</strong>
                    <span>OFF</span>
                </div>
                <div>
                    <span class="offer-kicker">Limited Launch Invitation · [Confirm Terms]</span>
                    <h3 class="offer-title">Experience Connekt Homes this season</h3>
                    <p class="offer-desc">Enjoy 15% savings across all Pali Hill and Bandra serviced residences when booking directly online.</p>
                </div>
            </div>
            <div class="offer-right">
                <div class="code-box">
                    <span>PROMO CODE</span>
                    <code>CONNEKT15</code>
                </div>
                <a href="<?php echo esc_url( home_url( '/stays' ) ); ?>" class="btn-primary">Claim & Book &rarr;</a>
            </div>
        </div>
    </div>
</section>
